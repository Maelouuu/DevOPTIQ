-- ==== début script Postgres/Neon ====
BEGIN;

-- on force l'encodage UTF-8
SET client_encoding = 'UTF8';

-- on évite les soucis de retours à la ligne dans les gros INSERT
SET standard_conforming_strings = on;

CREATE TABLE alembic_version (
	version_num VARCHAR(32) NOT NULL, 
	CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);
INSERT INTO alembic_version VALUES('4fe1f56bda52');
CREATE TABLE activities (
	id INTEGER NOT NULL, 
	shape_id VARCHAR(50), 
	name VARCHAR(200) NOT NULL, 
	description TEXT, 
	is_result BOOLEAN NOT NULL, duration_minutes REAL DEFAULT 0, delay_minutes    REAL DEFAULT 0, 
	PRIMARY KEY (id)
);
INSERT INTO activities VALUES(1,'669','Mise ├á jour du Web','',false,75.0,1440.0);
INSERT INTO activities VALUES(2,'672','Traitement de la demande','',false,0.0,0.0);
INSERT INTO activities VALUES(3,'674','Analyse de faisabilit├®','',false,0.0,0.0);
INSERT INTO activities VALUES(4,'676','R├®alisation de lÔÇÖoffre','',false,0.0,0.0);
INSERT INTO activities VALUES(5,'679','Pr├®paration projet','',false,0.0,0.0);
INSERT INTO activities VALUES(6,'684','Prise en compte de lÔÇÖoffre','',1::boolean,0.0,0.0);
INSERT INTO activities VALUES(7,'686','Cotation','',false,0.0,0.0);
INSERT INTO activities VALUES(8,'1000','N├®gociation de lÔÇÖ offre','',false,0.0,0.0);
INSERT INTO activities VALUES(9,'1016','Test laboratoire','',false,0.0,0.0);
INSERT INTO activities VALUES(10,'1022','Comit├® de d├®cision','',1::boolean,0.0,0.0);
INSERT INTO activities VALUES(11,'1025','Contr├┤le Qualit├®','',false,260.0,2880.0);
INSERT INTO activities VALUES(12,'1027','Contr├┤le fournisseur','',1::boolean,0.0,0.0);
INSERT INTO activities VALUES(13,'1045','R├®alisation des facture','',false,0.0,0.0);
INSERT INTO activities VALUES(14,'1049','Consultation du site','',1::boolean,0.0,0.0);
INSERT INTO activities VALUES(15,'1052','Relance','',false,0.0,0.0);
INSERT INTO activities VALUES(16,'1055','Encaissement','',false,0.0,0.0);
CREATE TABLE data (
	id INTEGER NOT NULL, 
	shape_id VARCHAR(50), 
	name VARCHAR(255) NOT NULL, 
	type VARCHAR(50) NOT NULL, 
	description TEXT, 
	layer VARCHAR(50), 
	PRIMARY KEY (id)
);
INSERT INTO data VALUES(1,'675','Lancement  de lÔÇÖÔÇÖanalyse de faisabilit├®','d├®clenchante','','T link');
INSERT INTO data VALUES(2,'680','Lancement pr├®-projet','d├®clenchante','','T link');
INSERT INTO data VALUES(3,'681','Offre ├á r├®aliser','d├®clenchante','','T link');
INSERT INTO data VALUES(4,'682','Liste des composants','d├®clenchante','','T link');
INSERT INTO data VALUES(5,'683','Planning pr├®visionnel projet','nourrissante','','N link');
INSERT INTO data VALUES(6,'685','Offre','d├®clenchante','','T link');
INSERT INTO data VALUES(7,'687','Demande de cotation','d├®clenchante','','T link');
INSERT INTO data VALUES(8,'688','cotation','nourrissante','','N link');
INSERT INTO data VALUES(9,'689','Produits s├®lectionn├®s','nourrissante','','N link');
INSERT INTO data VALUES(10,'1001','Offre ├á suivre','d├®clenchante','','T link');
INSERT INTO data VALUES(11,'1002','Mise ├á jour du Web','Retour','','');
INSERT INTO data VALUES(12,'1003','Enqu├¬te client','nourrissante','','N link');
INSERT INTO data VALUES(14,'1005','Enqu├¬te client','nourrissante','','N link');
INSERT INTO data VALUES(15,'1017','Demande de tests qualit├®','d├®clenchante','','T link');
INSERT INTO data VALUES(16,'1018','Pr├®paration projet','Retour','','');
INSERT INTO data VALUES(17,'1019','Test laboratoire','Retour','','');
INSERT INTO data VALUES(18,'1020','Feuille de test','nourrissante','','N link');
INSERT INTO data VALUES(19,'1021','Feuille de test','nourrissante','','N link');
INSERT INTO data VALUES(20,'1023','R├®sultat str├®t├®gique','nourrissante','','N link');
INSERT INTO data VALUES(21,'1024','Ajustement','d├®clenchante','','T link');
INSERT INTO data VALUES(22,'1026','Evaluation produit','d├®clenchante','','T link');
INSERT INTO data VALUES(23,'1028','R├®sultat contr├┤le produit','nourrissante','','N link');
INSERT INTO data VALUES(25,'1032','Contr├┤le Qualit├®','Retour','','');
INSERT INTO data VALUES(26,'1033','Analyse de faisabilit├®','Retour','','');
INSERT INTO data VALUES(28,'1035','REX','nourrissante','','N link');
INSERT INTO data VALUES(29,'1036','REX','nourrissante','','N link');
INSERT INTO data VALUES(30,'1037','Feuille de prix','nourrissante','','N link');
INSERT INTO data VALUES(31,'1043','AMDEC','nourrissante','','N link');
INSERT INTO data VALUES(32,'1044','AMDEC','nourrissante','','N link');
INSERT INTO data VALUES(33,'1046','Bon de commande','d├®clenchante','','T link');
INSERT INTO data VALUES(34,'1048','Demande de n├®gociation','nourrissante','','N link');
INSERT INTO data VALUES(35,'1050','Consutation','d├®clenchante','','T link');
INSERT INTO data VALUES(36,'1051','Update','d├®clenchante','','T link');
INSERT INTO data VALUES(42,'1053','Impay├®s','d├®clenchante','','T link');
INSERT INTO data VALUES(72,'1054','R├®sultat labo client','nourrissante','','N link');
INSERT INTO data VALUES(91,'1056','PAiement','d├®clenchante','','T link');
INSERT INTO data VALUES(178,'1034','N├®gociation de lÔÇÖ offre','Retour',NULL,NULL);
CREATE TABLE roles (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	onboarding_plan TEXT, mission_generale TEXT, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO roles VALUES(1,'manager',NULL,NULL);
INSERT INTO roles VALUES(2,'Relation clients','**1) Module de formation/entrainement :**\u000a\u000a**Formation 1: Analyse et traitement de l''information**\u000a- Objectifs : D├®velopper la capacit├® ├á analyser une demande client, v├®rifier la disponibilit├® dans le catalogue, et collecter les informations n├®cessaires pour la faisabilit├®.\u000a- Dur├®e : 1 jour\u000a- M├®thode : Formation interactive avec des ├®tudes de cas r├®els pour pratiquer l''analyse et le traitement de l''information. \u000a- Crit├¿res d''├®valuation : Capacit├® ├á analyser une demande client, ├á v├®rifier la disponibilit├® dans le catalogue, et ├á collecter les informations n├®cessaires pour la faisabilit├® dans un d├®lai donn├®.\u000a\u000a**Formation 2: Auto-organisation et planification**\u000a- Objectifs : Am├®liorer l''auto-organisation et la planification pour respecter les contraintes et les performances.\u000a- Dur├®e : 1 jour\u000a- M├®thode : Ateliers pratiques sur la gestion du temps et des ressources, et la planification des t├óches.\u000a- Crit├¿res d''├®valuation : Capacit├® ├á s''auto-organiser et ├á planifier ses actions en tenant compte des disponibilit├®s des ├®quipes et des d├®lais ├á respecter.\u000a\u000a**Formation 3: Coop├®ration et flexibilit├® mentale**\u000a- Objectifs : Renforcer la coop├®ration et la flexibilit├® mentale pour s''adapter aux diff├®rentes demandes des clients et trouver des solutions en cas de non-disponibilit├® dans le catalogue.\u000a- Dur├®e : 1 jour\u000a- M├®thode : Jeux de r├┤le et simulations pour pratiquer la coop├®ration et la flexibilit├® mentale.\u000a- Crit├¿res d''├®valuation : Capacit├® ├á coop├®rer avec les autres membres de l''├®quipe et ├á s''adapter aux diff├®rentes demandes des clients.\u000a\u000a**2) Retour dÔÇÖExp├®rience (REX) :**\u000a\u000aUne session de REX pourrait ├¬tre organis├®e sous forme de r├®union d''├®quipe o├╣ chaque membre partage ses exp├®riences li├®es aux HSC. Par exemple, un membre de l''├®quipe pourrait partager comment il a g├®r├® une demande client complexe en utilisant ses comp├®tences en analyse et traitement de l''information, et comment il a planifi├® ses actions pour respecter les d├®lais. Les autres membres de l''├®quipe pourraient ensuite donner leur feedback et partager leurs propres exp├®riences similaires. Cette session serait anim├®e par un facilitateur qui guiderait la discussion et s''assurerait que tous les membres de l''├®quipe ont l''opportunit├® de partager leurs exp├®riences.\u000a\u000a**3) Coaching dÔÇÖ├ëquipe :**\u000a\u000aLe coaching d''├®quipe pourrait se concentrer sur le renforcement de la coop├®ration, de l''auto-organisation et de l''adaptation. Par exemple, le coach pourrait organiser des ateliers pour pratiquer ces comp├®tences, comme des jeux de r├┤le o├╣ les membres de l''├®quipe doivent collaborer pour r├®soudre un probl├¿me, ou des simulations o├╣ ils doivent s''adapter ├á des changements inattendus. Le coach pourrait ├®galement donner des feedbacks individuels pour aider chaque membre de l''├®quipe ├á am├®liorer ses comp├®tences.\u000a\u000a**4) Parcours dÔÇÖApprentissage Autonome :**\u000a\u000aLe parcours d''apprentissage autonome pourrait inclure des micro-formations en ligne sur les HSC, comme des vid├®os ou des articles sur l''analyse et le traitement de l''information, l''auto-organisation et la planification, la coop├®ration et la flexibilit├® mentale. Il pourrait ├®galement inclure des exercices pratiques pour appliquer ces comp├®tences, comme des ├®tudes de cas ├á analyser, des t├óches ├á planifier, ou des situations ├á g├®rer en coop├®ration avec d''autres. Enfin, il pourrait inclure des quiz pour ├®valuer la compr├®hension et l''application des comp├®tences.',NULL);
INSERT INTO roles VALUES(3,'Coordination projet','Plan d''accompagnement pour le d├®veloppement des habilet├®s sociocognitives (HSC) pour le r├┤le "Coordination projet"\u000a\u000a1) Plan de d├®veloppement des HSC\u000a\u000aa) Module "Gestion de projet et Auto-organisation" - HSC vis├®e: Auto-organisation (Niveau: 3)\u000aObjectifs : Renforcer la capacit├® ├á organiser son travail de mani├¿re autonome, ├á d├®finir ses priorit├®s et ├á g├®rer son temps efficacement.\u000aDur├®e : 2 jours\u000aM├®thode : Ateliers pratiques sur la gestion du temps et des priorit├®s, exercices de simulation de projets.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á organiser leur travail et ├á g├®rer leur temps dans le cadre de simulations de projets, ce qui leur permet de d├®velopper leur auto-organisation.\u000a\u000ab) Module "Planification strat├®gique" - HSC vis├®e: Planification (Niveau: 3)\u000aObjectifs : Am├®liorer les comp├®tences en mati├¿re de planification de projets, de d├®finition d''objectifs et de mise en ┼ôuvre de plans d''action.\u000aDur├®e : 2 jours\u000aM├®thode : ├ëtudes de cas, jeux de r├┤le sur la planification de projets.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á planifier des projets de A ├á Z, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re de planification.\u000a\u000a2) Retour dÔÇÖExp├®rience (REX)\u000a\u000aa) Module "Analyse et traitement de l''information" - HSC vis├®e: Traitement de lÔÇÖinformation (Niveau: 2)\u000aObjectifs : Renforcer la capacit├® ├á analyser et ├á traiter l''information de mani├¿re efficace.\u000aDur├®e : 1 jour\u000aM├®thode : Ateliers de partage d''exp├®riences, analyse de cas r├®els.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á analyser des situations r├®elles et ├á traiter l''information, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re de traitement de l''information.\u000a\u000ab) Module "Arbitrage et prise de d├®cision" - HSC vis├®e: Arbitrage (Niveau: 2)\u000aObjectifs : Am├®liorer les comp├®tences en mati├¿re d''arbitrage et de prise de d├®cision.\u000aDur├®e : 1 jour\u000aM├®thode : Jeux de r├┤le, ├®tudes de cas.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á prendre des d├®cisions dans des situations simul├®es, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re d''arbitrage.\u000a\u000a3) Coaching dÔÇÖ├ëquipe\u000a\u000aa) Module "Adaptation relationnelle et travail en ├®quipe" - HSC vis├®e: Adaptation relationnelle (Niveau: 2)\u000aObjectifs : Am├®liorer les comp├®tences en mati├¿re de travail en ├®quipe et d''adaptation relationnelle.\u000aDur├®e : 2 jours\u000aM├®thode : Jeux de r├┤le, exercices de team building.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á travailler en ├®quipe et ├á s''adapter ├á diff├®rentes personnalit├®s, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re d''adaptation relationnelle.\u000a\u000a4) Parcours dÔÇÖApprentissage Autonome\u000a\u000aa) Module "Conceptualisation et pens├®e critique" - HSC vis├®e: Conceptualisation (Niveau: 4)\u000aObjectifs : Renforcer la capacit├® ├á conceptualiser des id├®es et ├á penser de mani├¿re critique.\u000aDur├®e : Auto-apprentissage ├á son rythme\u000aM├®thode : Cours en ligne, lectures recommand├®es, exercices pratiques.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á conceptualiser des id├®es et ├á penser de mani├¿re critique ├á travers des exercices pratiques et des lectures, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re de conceptualisation.\u000a\u000ab) Module "Flexibilit├® mentale et r├®solution de probl├¿mes" - HSC vis├®e: Flexibilit├® mentale (Niveau: 2)\u000aObjectifs : Am├®liorer la flexibilit├® mentale et la capacit├® ├á r├®soudre des probl├¿mes.\u000aDur├®e : Auto-apprentissage ├á son rythme\u000aM├®thode : Cours en ligne, lectures recommand├®es, exercices pratiques.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á r├®soudre des probl├¿mes et ├á faire preuve de flexibilit├® mentale ├á travers des exercices pratiques et des lectures, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re de flexibilit├® mentale.\u000a\u000ac) Module "Approche globale et vision strat├®gique" - HSC vis├®e: Approche globale (Niveau: 4)\u000aObjectifs : Renforcer la capacit├® ├á avoir une vision globale et ├á penser de mani├¿re strat├®gique.\u000aDur├®e : Auto-apprentissage ├á son rythme\u000aM├®thode : Cours en ligne, lectures recommand├®es, exercices pratiques.\u000aD├®veloppement des HSC : Les participants sont amen├®s ├á avoir une vision globale et ├á penser de mani├¿re strat├®gique ├á travers des exercices pratiques et des lectures, ce qui leur permet de d├®velopper leur comp├®tence en mati├¿re d''approche globale.',NULL);
INSERT INTO roles VALUES(4,'Coster','Plan d''accompagnement pour le d├®veloppement des habilet├®s sociocognitives (HSC) du r├┤le "Coster"\u000a\u000aPartie I: Plan de d├®veloppement des HSC\u000a\u000aModule 1: Auto-organisation - Niveau: 3\u000aObjectifs: Am├®liorer la capacit├® ├á planifier, prioriser et g├®rer efficacement le temps et les ressources.\u000aDur├®e: 2 jours\u000aM├®thode: Ateliers pratiques sur la gestion du temps et des ressources, exercices de planification de projets.\u000aD├®veloppement des HSC: Les participants apprendront ├á s''organiser de mani├¿re autonome, en d├®finissant des priorit├®s et en g├®rant efficacement leur temps et leurs ressources.\u000a\u000aModule 2: Arbitrage - Niveau: 3\u000aObjectifs: D├®velopper la capacit├® ├á prendre des d├®cisions ├®quilibr├®es et justes.\u000aDur├®e: 2 jours\u000aM├®thode: Jeux de r├┤le sur des situations de prise de d├®cision, discussions de groupe sur des ├®tudes de cas.\u000aD├®veloppement des HSC: Les participants d├®velopperont leur capacit├® ├á arbitrer entre diff├®rentes options et ├á prendre des d├®cisions ├®quilibr├®es.\u000a\u000aPartie II: Retour dÔÇÖExp├®rience (REX)\u000a\u000aModule 3: Traitement de lÔÇÖinformation - Niveau: 3\u000aObjectifs: Am├®liorer la capacit├® ├á collecter, analyser et utiliser efficacement l''information.\u000aDur├®e: 2 jours\u000aM├®thode: Exercices pratiques sur la collecte et l''analyse d''informations, ├®tudes de cas sur l''utilisation de l''information pour la prise de d├®cision.\u000aD├®veloppement des HSC: Les participants apprendront ├á traiter efficacement l''information, en la collectant, en l''analysant et en l''utilisant pour prendre des d├®cisions ├®clair├®es.\u000a\u000aPartie III: Coaching dÔÇÖ├ëquipe\u000a\u000aModule 4: Raisonnement logique - Niveau: 2\u000aObjectifs: D├®velopper la capacit├® ├á r├®soudre des probl├¿mes et ├á prendre des d├®cisions bas├®es sur la logique.\u000aDur├®e: 2 jours\u000aM├®thode: Exercices de r├®solution de probl├¿mes, discussions de groupe sur des ├®tudes de cas.\u000aD├®veloppement des HSC: Les participants d├®velopperont leur capacit├® ├á utiliser le raisonnement logique pour r├®soudre des probl├¿mes et prendre des d├®cisions.\u000a\u000aPartie IV: Parcours dÔÇÖApprentissage Autonome\u000a\u000aModule 5: Adaptation relationnelle - Niveau: 4\u000aObjectifs: Am├®liorer la capacit├® ├á interagir efficacement avec les autres et ├á s''adapter ├á diff├®rentes situations sociales.\u000aDur├®e: 3 jours\u000aM├®thode: Jeux de r├┤le sur des situations sociales vari├®es, feedback et coaching individuel.\u000aD├®veloppement des HSC: Les participants d├®velopperont leur capacit├® ├á s''adapter ├á diff├®rentes situations sociales et ├á interagir efficacement avec les autres.\u000a\u000aCe plan d''accompagnement vise ├á d├®velopper les HSC n├®cessaires pour le r├┤le de "Coster", en offrant une formation et un accompagnement cibl├®s sur les comp├®tences cl├®s n├®cessaires pour ce r├┤le.',NULL);
INSERT INTO roles VALUES(5,'Controle produit','',NULL);
INSERT INTO roles VALUES(6,'Qualit├®','',NULL);
INSERT INTO roles VALUES(7,'Administration','',NULL);
INSERT INTO roles VALUES(8,'Suivi des mesure qualit├®','Plan d''accompagnement pour le d├®veloppement des habilet├®s sociocognitives (HSC) :\u000a\u000aI. Plan de d├®veloppement des HSC\u000a\u000aModule 1 : Auto-├®valuation - Niveau: 1\u000aObjectif : Am├®liorer la capacit├® ├á ├®valuer ses propres performances et ├á identifier ses points forts et faiblesses.\u000aDur├®e : 1 jour\u000aM├®thode : Exercices pratiques d''auto-├®valuation, feedback de pairs et de formateurs.\u000aD├®veloppement des HSC : L''apprenant am├®liore son auto-├®valuation en identifiant ses points forts et faiblesses et en d├®finissant des strat├®gies pour am├®liorer ses performances.\u000a\u000aModule 2 : Auto-organisation - Niveau: 4\u000aObjectif : D├®velopper des comp├®tences avanc├®es en gestion du temps et en organisation personnelle.\u000aDur├®e : 2 jours\u000aM├®thode : Ateliers pratiques sur la gestion du temps, l''organisation personnelle et la d├®finition des priorit├®s.\u000aD├®veloppement des HSC : L''apprenant renforce son auto-organisation en d├®veloppant des comp├®tences en gestion du temps et en organisation personnelle.\u000a\u000aII. Retour dÔÇÖExp├®rience (REX)\u000a\u000aModule 3 : Raisonnement logique - Niveau: 2\u000aObjectif : Am├®liorer la capacit├® ├á r├®soudre des probl├¿mes et ├á prendre des d├®cisions bas├®es sur la logique et les faits.\u000aDur├®e : 2 jours\u000aM├®thode : ├ëtudes de cas, exercices de r├®solution de probl├¿mes et jeux de r├┤le.\u000aD├®veloppement des HSC : L''apprenant am├®liore son raisonnement logique en r├®solvant des probl├¿mes et en prenant des d├®cisions bas├®es sur la logique et les faits.\u000a\u000aIII. Coaching dÔÇÖ├ëquipe\u000a\u000aModule 4 : Planification - Niveau: 3\u000aObjectif : D├®velopper des comp├®tences en planification et en gestion de projet.\u000aDur├®e : 3 jours\u000aM├®thode : Ateliers de planification de projet, jeux de r├┤le et feedback de pairs et de formateurs.\u000aD├®veloppement des HSC : L''apprenant renforce sa planification en d├®veloppant des comp├®tences en planification et en gestion de projet.\u000a\u000aIV. Parcours dÔÇÖApprentissage Autonome\u000a\u000aModule 5 : Arbitrage - Niveau: 2\u000aObjectif : Am├®liorer la capacit├® ├á arbitrer entre diff├®rentes options et ├á prendre des d├®cisions.\u000aDur├®e : 2 jours\u000aM├®thode : Jeux de r├┤le, ├®tudes de cas et exercices de prise de d├®cision.\u000aD├®veloppement des HSC : L''apprenant am├®liore son arbitrage en prenant des d├®cisions bas├®es sur l''analyse des options disponibles.\u000a\u000aCe plan d''accompagnement vise ├á d├®velopper les HSC n├®cessaires pour le r├┤le de "Suivi des mesure qualit├®". Chaque module est con├ºu pour d├®velopper une ou plusieurs HSC sp├®cifiques, en utilisant des m├®thodes p├®dagogiques appropri├®es et en offrant des opportunit├®s pour la pratique et le feedback.',NULL);
INSERT INTO roles VALUES(9,'Facturi├¿re','Plan d''accompagnement pour le d├®veloppement des habilet├®s sociocognitives (HSC) pour le poste de Facturi├¿re\u000a\u000aI. Plan de d├®veloppement des HSC\u000a\u000aModule 1: Auto-r├®gulation - Niveau: 3\u000aObjectifs: Am├®liorer la capacit├® ├á contr├┤ler ses ├®motions et comportements en situation de travail, ├á g├®rer le stress et ├á maintenir la motivation.\u000aDur├®e: 4 semaines\u000aM├®thode: Ateliers de gestion du stress, exercices de pleine conscience et de m├®ditation, coaching individuel.\u000aLien avec les HSC: Ce module vise directement ├á d├®velopper l''auto-r├®gulation, une comp├®tence essentielle pour g├®rer les situations stressantes et maintenir la performance au travail.\u000a\u000aModule 2: Traitement de lÔÇÖinformation - Niveau: 2\u000aObjectifs: Am├®liorer la capacit├® ├á analyser et synth├®tiser l''information, ├á prendre des d├®cisions bas├®es sur l''information disponible.\u000aDur├®e: 3 semaines\u000aM├®thode: Exercices pratiques d''analyse de donn├®es, jeux de r├┤le pour la prise de d├®cision, coaching individuel.\u000aLien avec les HSC: Ce module vise ├á d├®velopper le traitement de l''information, une comp├®tence cl├® pour analyser et utiliser efficacement l''information dans le travail de facturation.\u000a\u000aII. Retour dÔÇÖExp├®rience (REX)\u000a\u000aObjectifs: Partager les exp├®riences et les le├ºons apprises, promouvoir l''apprentissage continu.\u000aDur├®e: 1 journ├®e par mois\u000aM├®thode: R├®unions d''├®quipe pour partager les exp├®riences, ├®changes de bonnes pratiques.\u000aLien avec les HSC: Le REX favorise le d├®veloppement de toutes les HSC en permettant aux participants de r├®fl├®chir sur leurs exp├®riences, d''apprendre des autres et d''am├®liorer leurs comp├®tences.\u000a\u000aIII. Coaching dÔÇÖ├ëquipe\u000a\u000aObjectifs: Renforcer la coh├®sion d''├®quipe, am├®liorer la communication et la collaboration.\u000aDur├®e: 2 heures par semaine\u000aM├®thode: Ateliers de team building, coaching de groupe.\u000aLien avec les HSC: Le coaching d''├®quipe contribue au d├®veloppement de l''auto-r├®gulation et de l''auto-organisation en am├®liorant la capacit├® ├á travailler en ├®quipe et ├á g├®rer les relations interpersonnelles.\u000a\u000aIV. Parcours dÔÇÖApprentissage Autonome\u000a\u000aModule 1: Auto-organisation - Niveau: 3\u000aObjectifs: Am├®liorer la capacit├® ├á planifier et ├á organiser son travail de mani├¿re autonome.\u000aDur├®e: 4 semaines\u000aM├®thode: Exercices pratiques de planification, coaching individuel.\u000aLien avec les HSC: Ce module vise directement ├á d├®velopper l''auto-organisation, une comp├®tence cl├® pour g├®rer efficacement son temps et ses t├óches.\u000a\u000aModule 2: Raisonnement logique - Niveau: 2\u000aObjectifs: Am├®liorer la capacit├® ├á r├®soudre des probl├¿mes et ├á prendre des d├®cisions de mani├¿re logique et structur├®e.\u000aDur├®e: 3 semaines\u000aM├®thode: Jeux de r├┤le pour la r├®solution de probl├¿mes, exercices de logique, coaching individuel.\u000aLien avec les HSC: Ce module vise ├á d├®velopper le raisonnement logique, une comp├®tence essentielle pour r├®soudre les probl├¿mes et prendre des d├®cisions efficaces.\u000a\u000aModule 3: Planification - Niveau: 2\u000aObjectifs: Am├®liorer la capacit├® ├á planifier et ├á prioriser les t├óches.\u000aDur├®e: 3 semaines\u000aM├®thode: Exercices pratiques de planification, coaching individuel.\u000aLien avec les HSC: Ce module vise ├á d├®velopper la planification, une comp├®tence cl├® pour organiser son travail et atteindre ses objectifs.',NULL);
INSERT INTO roles VALUES(10,'Site dessinateur','',NULL);
INSERT INTO roles VALUES(11,'Support finance','',NULL);
INSERT INTO roles VALUES(12,'Utilisateur','',NULL);
INSERT INTO roles VALUES(13,'Web designer','**1) Module de formation/entrainement :**\u000a\u000a**Formation 1 : Flexibilit├® mentale**\u000a- Objectifs : Comprendre la notion de flexibilit├® mentale, apprendre ├á s''adapter aux changements et ├á modifier ses m├®thodes de travail en fonction des situations.\u000a- Dur├®e : 0,5 jour\u000a- M├®thode : Exercices pratiques de r├®solution de probl├¿mes, jeux de r├┤le pour s''adapter ├á des situations inattendues.\u000a- Crit├¿res d''├®valuation : Capacit├® ├á s''adapter ├á des situations nouvelles lors d''exercices de simulation, feedback des pairs.\u000a\u000a**Formation 2 : Synth├¿se et raisonnement logique**\u000a- Objectifs : D├®velopper la capacit├® ├á synth├®tiser des informations et ├á utiliser le raisonnement logique pour prendre des d├®cisions.\u000a- Dur├®e : 1 jour\u000a- M├®thode : Exercices de synth├¿se d''informations, jeux de logique, ├®tudes de cas.\u000a- Crit├¿res d''├®valuation : Qualit├® des synth├¿ses r├®alis├®es, capacit├® ├á r├®soudre des probl├¿mes logiques, application du raisonnement logique dans les ├®tudes de cas.\u000a\u000a**Formation 3 : Auto-organisation et sensibilit├® sociale**\u000a- Objectifs : Am├®liorer la capacit├® ├á s''organiser de mani├¿re autonome et ├á comprendre les ├®motions et les besoins des autres.\u000a- Dur├®e : 1,5 jour\u000a- M├®thode : Ateliers de gestion du temps, exercices de mise en situation pour d├®velopper l''empathie.\u000a- Crit├¿res d''├®valuation : Am├®lioration de l''organisation personnelle, capacit├® ├á comprendre et ├á r├®pondre aux ├®motions des autres.\u000a\u000a**2) Retour dÔÇÖExp├®rience (REX) :**\u000a\u000aLa session de REX sera ax├®e sur l''analyse de situations v├®cues par les participants au cours desquelles ils ont d├╗ faire preuve de flexibilit├® mentale, de synth├¿se, d''auto-organisation, de sensibilit├® sociale et de raisonnement logique. Chaque participant pr├®sentera une situation, les actions qu''il a entreprises et les r├®sultats obtenus. Les autres participants et l''animateur donneront leur feedback et proposeront des alternatives pour am├®liorer les HSC. \u000a\u000a**3) Coaching dÔÇÖ├ëquipe :**\u000a\u000aPour renforcer la coop├®ration, lÔÇÖauto-organisation et lÔÇÖadaptation, le coach devra :\u000a- Encourager la communication ouverte et honn├¬te au sein de l''├®quipe.\u000a- Proposer des exercices de team building pour renforcer la coop├®ration.\u000a- Mettre en place des rituels d''organisation (planning hebdomadaire, r├®unions de suivi...).\u000a- Encourager l''initiative personnelle et la prise de d├®cision en ├®quipe.\u000a- Proposer des exercices de flexibilit├® mentale pour aider l''├®quipe ├á s''adapter aux changements.\u000a\u000a**4) Parcours dÔÇÖApprentissage Autonome :**\u000a\u000aLe parcours d''apprentissage autonome pourra inclure :\u000a- Des micro-formations en ligne sur la flexibilit├® mentale, la synth├¿se, l''auto-organisation, la sensibilit├® sociale et le raisonnement logique.\u000a- Des exercices pratiques ├á r├®aliser en autonomie pour d├®velopper ces HSC (par exemple, des exercices de synth├¿se d''articles, des jeux de logique...).\u000a- Des quiz pour ├®valuer les progr├¿s r├®alis├®s dans le d├®veloppement de ces HSC.',NULL);
INSERT INTO roles VALUES(14,'Animateur R├®seaux sociaux','',NULL);
INSERT INTO roles VALUES(15,'Intrant',NULL,NULL);
INSERT INTO roles VALUES(16,'Extrant',NULL,NULL);
INSERT INTO roles VALUES(17,'Analyse',NULL,NULL);
INSERT INTO roles VALUES(18,'D├®veloppeur',NULL,NULL);
INSERT INTO roles VALUES(19,'Testeur',NULL,NULL);
INSERT INTO roles VALUES(20,'Gestionnaire de produit',NULL,NULL);
INSERT INTO roles VALUES(22,'Rôle importé 22',NULL,NULL);
INSERT INTO roles VALUES(110,'D├®veloppeur Web',NULL,NULL);
INSERT INTO roles VALUES(111,'Rôle importé 111',NULL,NULL);
INSERT INTO roles VALUES(112,'Testeur QA',NULL,NULL);
INSERT INTO roles VALUES(113,'Chef de projet',NULL,NULL);
INSERT INTO roles VALUES(114,'Pilote commercial',NULL,NULL);
CREATE TABLE tools (
	id INTEGER NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	description TEXT, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO tools VALUES(1,'Check list','');
INSERT INTO tools VALUES(2,'Ficheiers produits','');
INSERT INTO tools VALUES(3,'Dossier de faisabilit├®','');
INSERT INTO tools VALUES(4,'Word Template','');
INSERT INTO tools VALUES(5,'PowerPoint template','');
INSERT INTO tools VALUES(6,'Liste Ing├®nieurs','');
INSERT INTO tools VALUES(7,'planning','');
INSERT INTO tools VALUES(8,'Base fournisseurs','');
INSERT INTO tools VALUES(9,'Logiciel de mesure','');
INSERT INTO tools VALUES(10,'feue de r├®sultat','');
INSERT INTO tools VALUES(11,'Fichier de comparaison','');
INSERT INTO tools VALUES(12,'base des pris','');
INSERT INTO tools VALUES(13,'Feuille de prix','');
INSERT INTO tools VALUES(14,'Logicial facture','');
INSERT INTO tools VALUES(15,'Instruments de mesure','');
INSERT INTO tools VALUES(16,'relev├®s de mesures','');
INSERT INTO tools VALUES(17,'Base d''enregistrement des contr├┤les','');
INSERT INTO tools VALUES(18,'Ficheirs des sp├®cificartions','');
INSERT INTO tools VALUES(19,'feuille de comparaison','');
INSERT INTO tools VALUES(20,'Autocad',NULL);
INSERT INTO tools VALUES(21,'Logiciel Dessin','');
INSERT INTO tools VALUES(22,'MAquettee synth├¿se faisabilit├®','');
INSERT INTO tools VALUES(23,'Interrogateur Ping','');
INSERT INTO tools VALUES(24,'wordpress','');
INSERT INTO tools VALUES(25,'Tableau des codes produits','');
INSERT INTO tools VALUES(26,'CRM Suivi client','');
INSERT INTO tools VALUES(27,'web analisys',NULL);
INSERT INTO tools VALUES(28,'Photoshop',NULL);
INSERT INTO tools VALUES(29,'Catalogue',NULL);
INSERT INTO tools VALUES(30,'Template PPT Offer',NULL);
INSERT INTO tools VALUES(31,'Canal Team Projet',NULL);
INSERT INTO tools VALUES(32,'Feasability Check',NULL);
CREATE TABLE activity_roles (
	activity_id INTEGER NOT NULL, 
	role_id INTEGER NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	PRIMARY KEY (activity_id, role_id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id), 
	FOREIGN KEY(role_id) REFERENCES roles (id)
);
INSERT INTO activity_roles VALUES(2,2,'Garant');
INSERT INTO activity_roles VALUES(1,13,'Garant');
INSERT INTO activity_roles VALUES(7,7,'Garant');
INSERT INTO activity_roles VALUES(6,2,'Garant');
INSERT INTO activity_roles VALUES(14,111,'Garant');
INSERT INTO activity_roles VALUES(13,112,'Garant');
INSERT INTO activity_roles VALUES(16,4,'Garant');
INSERT INTO activity_roles VALUES(9,10,'Garant');
INSERT INTO activity_roles VALUES(10,2,'Garant');
INSERT INTO activity_roles VALUES(4,2,'Garant');
INSERT INTO activity_roles VALUES(5,113,'Garant');
INSERT INTO activity_roles VALUES(3,2,'Garant');
INSERT INTO activity_roles VALUES(11,13,'Garant');
CREATE TABLE aptitudes (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	activity_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO aptitudes VALUES(3,'mais nan dingue',9);
CREATE TABLE competencies (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	activity_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO competencies VALUES(7,'- N├®gocie fermement et de mani├¿re strat├®gique pour obtenir le paiement en temps opportun.',15);
INSERT INTO competencies VALUES(10,'- Compare les produits existants en se basant sur les r├®sultats de tests pr├®c├®demment enregistr├®s.',9);
INSERT INTO competencies VALUES(11,'- ├ëtablit une feuille de prix en se basant sur une base de prix pour assurer une ├®valuation pr├®cise et ├®quitable.',7);
INSERT INTO competencies VALUES(12,'- Met ├á jour la comptabilit├® client et envoie la facture pour maintenir une communication efficace et une gestion financi├¿re pr├®cise.',13);
INSERT INTO competencies VALUES(13,'- Synth├®tise et compare les mesures obtenues pour garantir la qualit├® et la conformit├® des produits ou services.',11);
INSERT INTO competencies VALUES(16,'Compétence importée 16',1);
INSERT INTO competencies VALUES(15,'Compétence importée 15',1);
INSERT INTO competencies VALUES(17,'Compétence importée 17',1);
INSERT INTO competencies VALUES(18,'Compétence importée 18',1);
INSERT INTO competencies VALUES(19,'Compétence importée 19',1);
INSERT INTO competencies VALUES(20,'Assimiler la demande et les objections du client pour mieux comprendre ses besoins et attentes lors de la n├®gociation de l''offre.',8);
INSERT INTO competencies VALUES(21,'Publier les pages modifi├®es apr├¿s avoir effectu├® un contr├┤le de l\''historique et v├®rifi├® les pings.',1);
INSERT INTO competencies VALUES(22,'Analyser pr├®cis├®ment la demande du client en utilisant les outils de catalogue et de check-list.',2);
INSERT INTO competencies VALUES(23,'R├®diger un rapport de faisabilit├® d├®taill├® pour transmettre les r├®sultats de l\''analyse aux ├®quipes concern├®es.',3);
CREATE TABLE constraints (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	activity_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO constraints VALUES(7,'Respecter les plannings des ├®quipes',5);
INSERT INTO constraints VALUES(14,'Respecter l''ortographe',1);
INSERT INTO constraints VALUES(15,'Sans faute',4);
INSERT INTO constraints VALUES(16,'Respect nomenclature catalogue',2);
INSERT INTO constraints VALUES(17,'utiliser Json',1);
INSERT INTO constraints VALUES(18,'finalisez le projet pour le 17/05',1);
INSERT INTO constraints VALUES(19,'Conforme logo',4);
INSERT INTO constraints VALUES(20,'Prise en compte de la dispo des ├®quipes',3);
CREATE TABLE links (
	id INTEGER NOT NULL, 
	source_activity_id INTEGER, 
	source_data_id INTEGER, 
	target_activity_id INTEGER, 
	target_data_id INTEGER, 
	type VARCHAR(50) NOT NULL, 
	description TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_activity_id) REFERENCES activities (id), 
	FOREIGN KEY(source_data_id) REFERENCES data (id), 
	FOREIGN KEY(target_activity_id) REFERENCES activities (id), 
	FOREIGN KEY(target_data_id) REFERENCES data (id)
);
INSERT INTO links VALUES(1,2,NULL,3,NULL,'d├®clenchante','Lancement  de lÔÇÖÔÇÖanalyse de faisabilit├®');
INSERT INTO links VALUES(2,3,NULL,5,NULL,'d├®clenchante','Lancement pr├®-projet');
INSERT INTO links VALUES(3,3,NULL,4,NULL,'d├®clenchante','Offre ├á r├®aliser');
INSERT INTO links VALUES(4,1,NULL,3,NULL,'d├®clenchante','Liste des composants');
INSERT INTO links VALUES(5,5,NULL,4,NULL,'nourrissante','Planning pr├®visionnel projet');
INSERT INTO links VALUES(6,4,NULL,6,NULL,'d├®clenchante','Offre');
INSERT INTO links VALUES(7,5,NULL,7,NULL,'d├®clenchante','Demande de cotation');
INSERT INTO links VALUES(8,7,NULL,5,NULL,'nourrissante','cotation');
INSERT INTO links VALUES(9,5,NULL,7,NULL,'nourrissante','Produits s├®lectionn├®s');
INSERT INTO links VALUES(10,4,NULL,8,NULL,'d├®clenchante','Offre ├á suivre');
INSERT INTO links VALUES(11,8,NULL,1,NULL,'nourrissante','Enqu├¬te client');
INSERT INTO links VALUES(13,8,NULL,9,NULL,'d├®clenchante','Demande de tests qualit├®');
INSERT INTO links VALUES(14,9,NULL,5,NULL,'nourrissante','Feuille de test');
INSERT INTO links VALUES(15,10,NULL,8,NULL,'nourrissante','R├®sultat str├®t├®gique');
INSERT INTO links VALUES(16,8,NULL,10,NULL,'d├®clenchante','Ajustement');
INSERT INTO links VALUES(17,9,NULL,11,NULL,'d├®clenchante','Evaluation produit');
INSERT INTO links VALUES(18,11,NULL,12,NULL,'nourrissante','R├®sultat contr├┤le produit');
INSERT INTO links VALUES(19,8,NULL,3,NULL,'nourrissante','REX');
INSERT INTO links VALUES(20,7,NULL,4,NULL,'nourrissante','Feuille de prix');
INSERT INTO links VALUES(22,11,NULL,8,NULL,'nourrissante','AMDEC');
INSERT INTO links VALUES(23,10,NULL,13,NULL,'d├®clenchante','Bon de commande');
INSERT INTO links VALUES(24,6,NULL,8,NULL,'nourrissante','Demande de n├®gociation');
INSERT INTO links VALUES(25,14,NULL,2,NULL,'d├®clenchante','Consutation');
INSERT INTO links VALUES(26,1,NULL,14,NULL,'d├®clenchante','Update');
INSERT INTO links VALUES(27,13,NULL,15,NULL,'d├®clenchante','Impay├®s');
INSERT INTO links VALUES(28,10,NULL,9,NULL,'nourrissante','R├®sultat labo client');
INSERT INTO links VALUES(29,15,NULL,16,NULL,'d├®clenchante','PAiement');
CREATE TABLE savoir_faires (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	activity_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO savoir_faires VALUES(3,'D├®veloppement',1);
INSERT INTO savoir_faires VALUES(6,'Gestion de projet agile',1);
INSERT INTO savoir_faires VALUES(8,'Cr├®er et g├®rer une boutique en ligne avec Shopify.',1);
INSERT INTO savoir_faires VALUES(9,'R├®diger un rapport d''activit├®',2);
INSERT INTO savoir_faires VALUES(10,'Organiser un ├®v├®nement d''entreprise',2);
INSERT INTO savoir_faires VALUES(11,'Analyser une demande client',2);
INSERT INTO savoir_faires VALUES(12,'Mettre en place une strat├®gie de communication',2);
INSERT INTO savoir_faires VALUES(13,'Pr├®parer une pr├®sentation pour une r├®union d''├®quipe',2);
INSERT INTO savoir_faires VALUES(14,'N├®gocier un contrat avec un fournisseur',2);
INSERT INTO savoir_faires VALUES(15,'G├®rer un projet de A ├á Z',2);
INSERT INTO savoir_faires VALUES(16,'Effectuer des tests de contr├┤le qualit├® sur des ├®chantillons de produits',9);
INSERT INTO savoir_faires VALUES(17,'R├®diger un rapport d''activit├®',10);
INSERT INTO savoir_faires VALUES(18,'Documenter les r├®sultats de l''analyse dans le dossier de faisabilit├® pour assurer la tra├ºabilit├®.',2);
INSERT INTO savoir_faires VALUES(20,'Analyser les caract├®ristiques de la demande en utilisant le Catalogue.',3);
INSERT INTO savoir_faires VALUES(21,'Analyser les donn├®es d''entr├®e pour identifier les crit├¿res de contr├┤le des fournisseurs.',12);
INSERT INTO savoir_faires VALUES(22,'V├®rifier la conformit├® des proc├®dures de contr├┤le avec les normes en vigueur.',12);
INSERT INTO savoir_faires VALUES(23,'Informer les personnes sur les d├®lais et les responsabilit├®s via le Canal Team Projet.',5);
INSERT INTO savoir_faires VALUES(24,'R├®diger l''offre en respectant le template PPT Offer pour assurer une pr├®sentation coh├®rente.',4);
INSERT INTO savoir_faires VALUES(25,'Utiliser le tableau des codes produits pour v├®rifier la conformit├® des r├®f├®rences dans l''offre.',4);
CREATE TABLE savoirs (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	activity_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO savoirs VALUES(2,'test4c',2);
INSERT INTO savoirs VALUES(3,'Gestion de projet',1);
INSERT INTO savoirs VALUES(4,'D├®veloppement web',1);
INSERT INTO savoirs VALUES(5,'Analyse de donn├®es',1);
INSERT INTO savoirs VALUES(6,'Gestion des ressources humaines',1);
INSERT INTO savoirs VALUES(8,'Design Graphique',1);
INSERT INTO savoirs VALUES(9,'bonjour les jeunes',2);
INSERT INTO savoirs VALUES(10,'Comprendre les proc├®dures de manipulation des ├®chantillons dans un laboratoire de test.',9);
INSERT INTO savoirs VALUES(11,'Identifier les ├®quipements de s├®curit├® n├®cessaires dans un laboratoire de test.',9);
INSERT INTO savoirs VALUES(13,'R├¿gles de nomenclature du catalogue',2);
INSERT INTO savoirs VALUES(14,'Principes de faisabilit├® technique',2);
INSERT INTO savoirs VALUES(16,'R├¿gles de documentation des donn├®es d''entr├®e et de sortie pour la tra├ºabilit├®.',3);
INSERT INTO savoirs VALUES(17,'Normes ISO 9001 relatives ├á la gestion de la qualit├®.',12);
INSERT INTO savoirs VALUES(18,'Principes de gestion des risques li├®s aux fournisseurs.',12);
INSERT INTO savoirs VALUES(19,'R├¿gles de gestion de projet selon la norme ISO 21500.',5);
INSERT INTO savoirs VALUES(20,'Normes de r├®daction professionnelle (clart├®, pr├®cision, absence de fautes)',4);
INSERT INTO savoirs VALUES(21,'R├¿gles de conformit├® graphique (logo, mise en forme) selon la charte graphique de l''entreprise.',4);
INSERT INTO savoirs VALUES(22,'Normes de s├®curit├® de l''information (protection des donn├®es, acc├¿s aux outils).',1);
CREATE TABLE softskills (
	id INTEGER NOT NULL, 
	habilete VARCHAR(255) NOT NULL, 
	niveau VARCHAR(30) NOT NULL, 
	justification TEXT, 
	activity_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO softskills VALUES(51,'Traitement de lÔÇÖinformation','3','',7);
INSERT INTO softskills VALUES(52,'Raisonnement logique','2','',7);
INSERT INTO softskills VALUES(53,'Adaptation relationnelle','4','',7);
INSERT INTO softskills VALUES(72,'Planification','3','La rigueur n├®cessite ├®galement une bonne planification pour s''assurer que toutes les t├óches sont r├®alis├®es en temps et en heure.',9);
INSERT INTO softskills VALUES(73,'Auto-mobilisation','2','L''esprit d''initiative n├®cessite une certaine auto-mobilisation pour prendre des actions de mani├¿re proactive.',9);
INSERT INTO softskills VALUES(74,'Auto-organisation','3','La rigueur implique une bonne organisation personnelle pour g├®rer les t├óches de mani├¿re efficace et pr├®cise.',9);
INSERT INTO softskills VALUES(75,'Arbitrage','2','L''esprit d''initiative peut ├®galement impliquer de faire des choix et des d├®cisions, ce qui n├®cessite des comp├®tences en arbitrage.',9);
INSERT INTO softskills VALUES(76,'Raisonnement logique','2','La rigueur et l''esprit d''initiative n├®cessitent tous deux un raisonnement logique pour r├®soudre les probl├¿mes et prendre des d├®cisions.',9);
INSERT INTO softskills VALUES(77,'Auto-organisation','3','Un niveau ├®lev├® d''auto-organisation est n├®cessaire pour pr├®parer les conditions de test, ex├®cuter les mesures demand├®es et ├®tablir les relev├®s de mesure de mani├¿re efficace et ordonn├®e.',11);
INSERT INTO softskills VALUES(78,'Flexibilit├® mentale','2','La flexibilit├® mentale peut ├¬tre utile pour s''adapter ├á diff├®rentes situations de test et pour traiter des donn├®es variables. Un niveau interm├®diaire est suffisant pour cette activit├®.',11);
INSERT INTO softskills VALUES(79,'Synth├¿se','4','La capacit├® de synth├®tiser les informations est essentielle pour cette activit├®, en particulier lors de la r├®alisation de la synth├¿se comparative des mesures. Un niveau d''excellence est donc recommand├®.',11);
INSERT INTO softskills VALUES(80,'Raisonnement logique','3','La t├óche d''├®tablir les relev├®s de mesure et de faire la synth├¿se comparative des mesures n├®cessite un bon niveau de raisonnement logique pour analyser et interpr├®ter correctement les donn├®es.',11);
INSERT INTO softskills VALUES(81,'Auto-r├®gulation jeunesse','1 (aptitude)','L''autorit├® n├®cessite une auto-r├®gulation pour maintenir un ├®quilibre entre l''assertivit├® et la sensibilit├® aux besoins des autres.',11);
INSERT INTO softskills VALUES(82,'Arbitrage','2','L''autorit├® n├®cessite des comp├®tences en arbitrage pour prendre des d├®cisions ├®quilibr├®es et justes.',11);
INSERT INTO softskills VALUES(83,'Sensibilit├® sociale','1','L''autorit├® n├®cessite une certaine sensibilit├® sociale pour comprendre et r├®pondre aux besoins et aux attentes des autres.',11);
INSERT INTO softskills VALUES(84,'Planification','2','La rigueur n├®cessite une bonne planification pour s''assurer que les t├óches sont r├®alis├®es de mani├¿re ordonn├®e et dans les d├®lais.',11);
INSERT INTO softskills VALUES(90,'Sensibilit├® sociale','4','L''humour n├®cessite une compr├®hension profonde des sentiments, des r├®actions et des perspectives des autres. Il faut ├¬tre capable de percevoir ce qui peut faire rire les autres et de s''adapter ├á diff├®rents publics.',13);
INSERT INTO softskills VALUES(91,'Auto-├®valuation','2','L''utilisation de l''humour n├®cessite une certaine auto-├®valuation pour comprendre quand et comment l''utiliser de mani├¿re appropri├®e. Il faut ├¬tre capable de juger si une blague ou une remarque humoristique sera bien re├ºue ou non.',13);
INSERT INTO softskills VALUES(92,'Flexibilit├® mentale','3','L''humour n├®cessite souvent de penser de mani├¿re cr├®ative et de faire des liens inattendus. Une flexibilit├® mentale ├®lev├®e permet de cr├®er des blagues et des jeux de mots originaux.',13);
INSERT INTO softskills VALUES(93,'Auto-r├®gulation','2','L''humour n├®cessite une auto-r├®gulation pour ├®viter de faire des blagues inappropri├®es ou offensantes. Il faut ├¬tre capable de contr├┤ler ses impulsions et de r├®fl├®chir avant de parler.',13);
INSERT INTO softskills VALUES(94,'Adaptation relationnelle','3','L''humour peut ├¬tre un outil puissant pour ├®tablir des relations, mais il n├®cessite une capacit├® d''adaptation pour ├¬tre utilis├® efficacement. Il faut ├¬tre capable de moduler son humour en fonction de la situation et des personnes pr├®sentes.',13);
INSERT INTO softskills VALUES(95,'Auto-organisation','3','La t├óche n├®cessite une bonne organisation pour g├®rer efficacement les bons de commande, la facturation et la mise ├á jour de la comptabilit├® client. Un niveau de ma├«trise est donc n├®cessaire.',13);
INSERT INTO softskills VALUES(96,'Traitement de lÔÇÖinformation','2','La t├óche implique de traiter des informations provenant de diff├®rentes sources (bon de commande, facture, base fournisseurs). Un niveau d''acquisition est suffisant car bien que le traitement de l''information soit n├®cessaire, il ne s''agit pas de l''aspect le plus complexe de la t├óche.',13);
INSERT INTO softskills VALUES(97,'Raisonnement logique','3','La t├óche implique de rapprocher le bon de commande de la facture et de v├®rifier le fournisseur, ce qui n├®cessite un raisonnement logique pour identifier les erreurs ou les incoh├®rences. Un niveau de ma├«trise est donc appropri├®.',13);
INSERT INTO softskills VALUES(108,'Auto-├®valuation','3 (ma├«trise)','L''auto-├®valuation est essentielle pour la t├óche T1 (Prise en compte de la demande et des objections du client) afin de comprendre ses propres forces et faiblesses dans la n├®gociation. Cela contribue ├®galement ├á la performance P1 (Information ├á jour) en permettant une ├®valuation continue de l''efficacit├® de la n├®gociation.',8);
INSERT INTO softskills VALUES(109,'Adaptation relationnelle','4 (expertise)','L''adaptation relationnelle est cruciale pour la t├óche T3 (N├®gociation avec le client) pour s''adapter aux besoins et aux attentes du client. Cela aide ├®galement ├á atteindre la performance P2 (N├®gociation <15%) en permettant une n├®gociation efficace.',8);
INSERT INTO softskills VALUES(110,'Flexibilit├® mentale','2 (acquisition)','La flexibilit├® mentale est utile pour la t├óche T3 (N├®gociation avec le client) pour s''adapter aux changements et aux impr├®vus lors de la n├®gociation. Cela aide ├®galement ├á atteindre la performance P2 (N├®gociation <15%) en permettant une n├®gociation flexible et efficace.',8);
INSERT INTO softskills VALUES(111,'Synth├¿se','3 (ma├«trise)','La synth├¿se est importante pour la t├óche T4 (Faire le compte rendu de n├®go) pour r├®sumer efficacement les points cl├®s de la n├®gociation. Cela contribue ├®galement ├á la performance P1 (Information ├á jour) en garantissant que toutes les informations pertinentes sont communiqu├®es de mani├¿re concise.',8);
INSERT INTO softskills VALUES(112,'Raisonnement logique','2 (acquisition)','Le raisonnement logique est n├®cessaire pour la t├óche T2 (Construction d''un argumentaire) pour d├®velopper un argumentaire solide et convaincant. Cela contribue ├®galement ├á la performance P3 (Liste exhaustive ├á jour) en assurant que tous les points pertinents sont pris en compte dans l''argumentaire.',8);
INSERT INTO softskills VALUES(113,'Raisonnement logique','3 (Ma├«trise)','La qualit├® de rigueur est couverte par cette habilet├®. Dans la t├óche T1, v├®rifier avec le client la raison du retard de paiement n├®cessite un raisonnement logique pour comprendre les raisons du retard et proposer des solutions appropri├®es.',15);
INSERT INTO softskills VALUES(114,'Auto-r├®gulation','3 (Ma├«trise)','La qualit├® de fermet├® est couverte par cette habilet├®. Dans la t├óche T2, la n├®gociation ferme pour obtenir le paiement n├®cessite une auto-r├®gulation pour maintenir une position ferme sans ├¬tre agressif ou d├®sobligeant.',15);
INSERT INTO softskills VALUES(115,'Auto-mobilisation','4 (Excellence)','La qualit├® de conviction est couverte par cette habilet├®. Dans la t├óche T2, n├®gocier fermement pour obtenir le paiement n├®cessite une auto-mobilisation pour convaincre le client de l''importance du paiement en temps opportun, contribuant ainsi ├á la performance P1 de 95% de paiements sous 30 jours.',15);
INSERT INTO softskills VALUES(121,'Planification','2 (acquisition)','La planification est essentielle pour organiser les t├óches de collecte d''informations pour la faisabilit├® (T3) et pour s''assurer que la demande est trait├®e dans les 24 heures (P1).',2);
INSERT INTO softskills VALUES(122,'Auto-r├®gulation','2 (acquisition)','L''auto-r├®gulation est n├®cessaire pour g├®rer son temps et ses ressources afin de respecter la contrainte de traitement de la demande sous 24 heures (P1).',2);
INSERT INTO softskills VALUES(123,'Raisonnement logique','3 (ma├«trise)','Cette habilet├® est n├®cessaire pour analyser la demande du client (T1) et v├®rifier la disponibilit├® dans le catalogue (T2) tout en respectant la nomenclature du catalogue (C1).',2);
INSERT INTO softskills VALUES(124,'Traitement de lÔÇÖinformation','4 (expertise)','Cette comp├®tence est cruciale pour analyser la demande du client (T1), v├®rifier la disponibilit├® dans le catalogue (T2) et collecter les informations n├®cessaires pour la faisabilit├® (T3).',2);
INSERT INTO softskills VALUES(125,'Flexibilit├® mentale','1 (initiation)','La flexibilit├® mentale peut aider ├á s''adapter aux diff├®rentes demandes des clients et ├á trouver des solutions en cas de non-disponibilit├® dans le catalogue (T2).',2);
INSERT INTO softskills VALUES(131,'Synth├¿se','3 (Ma├«trise)','L''esprit de synth├¿se est essentiel pour effectuer la t├óche T4, qui consiste ├á ├®tablir le planning des parties prenantes. Il permet de rassembler et d''organiser efficacement les informations n├®cessaires pour respecter la contrainte C1, qui est de respecter les plannings des ├®quipes.',5);
INSERT INTO softskills VALUES(132,'Conceptualisation','2 (Acquisition)','L''esprit syst├®mique, qui est une forme de conceptualisation, est n├®cessaire pour la t├óche T2, qui consiste ├á identifier l''├®quipe projet. Cela permet de comprendre comment les diff├®rentes parties du projet interagissent entre elles et comment elles peuvent ├¬tre affect├®es par les diff├®rentes contraintes.',5);
INSERT INTO softskills VALUES(133,'Coop├®ration','1 (Initiation)','La coop├®ration est n├®cessaire pour toutes les t├óches, car elles impliquent toutes de travailler avec d''autres personnes. Cela est particuli├¿rement important pour la t├óche T4, qui consiste ├á ├®tablir le planning des parties prenantes, car cela n├®cessite de travailler en ├®troite collaboration avec toutes les parties prenantes pour s''assurer que leurs disponibilit├®s sont prises en compte.',5);
INSERT INTO softskills VALUES(134,'Adaptation relationnelle','3 (Ma├«trise)','Une bonne communication, qui est une forme d''adaptation relationnelle, est n├®cessaire pour la t├óche T1, qui consiste ├á informer les personnes. Cela permet de s''assurer que toutes les parties prenantes sont bien inform├®es et peuvent donc travailler efficacement ensemble.',5);
INSERT INTO softskills VALUES(135,'Planification','2 (Acquisition)','La planification est n├®cessaire pour la t├óche T3, qui consiste ├á pr├®-s├®lectionner les fournisseurs. Cela permet de s''assurer que les fournisseurs sont choisis en temps opportun et que le projet peut donc progresser selon le planning pr├®vu.',5);
INSERT INTO softskills VALUES(136,'Auto-organisation','3 (Ma├«trise)','L''auto-organisation est essentielle pour g├®rer les t├óches T1 ├á T4 de mani├¿re efficace et dans les d├®lais (P1, P2). Un individu engag├®, responsable et automotiv├® est capable de s''organiser de mani├¿re autonome pour accomplir ces t├óches.',3);
INSERT INTO softskills VALUES(137,'Synth├¿se','2 (Acquisition)','La capacit├® de synth├¿se est n├®cessaire pour faire le rapport de faisabilit├® (T4). Un individu engag├®, responsable et automotiv├® est capable de synth├®tiser les informations de mani├¿re claire et concise.',3);
INSERT INTO softskills VALUES(138,'Planification','2 (Acquisition)','La planification est n├®cessaire pour respecter les contraintes C1 et les performances P1 et P2. Un individu engag├®, responsable et automotiv├® est capable de planifier ses actions en tenant compte des disponibilit├®s des ├®quipes et des d├®lais ├á respecter.',3);
INSERT INTO softskills VALUES(139,'Coop├®ration','1 (Initiation)','La coop├®ration est n├®cessaire pour transmettre aux ├®quipes (T1) et prendre en compte la disponibilit├® des ├®quipes (C1). Un individu engag├®, responsable et automotiv├® est capable de coop├®rer avec les autres membres de l''├®quipe pour r├®aliser ces t├óches.',3);
INSERT INTO softskills VALUES(140,'Traitement de lÔÇÖinformation','3 (Ma├«trise)','Le traitement de l''information est crucial pour identifier les caract├®ristiques de la demande (T2) et analyser les contraintes techniques (T3). Un individu engag├®, responsable et automotiv├® est capable de traiter efficacement les informations pour r├®aliser ces t├óches.',3);
CREATE TABLE tasks (
	id INTEGER NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	description TEXT, 
	"order" INTEGER, 
	activity_id INTEGER NOT NULL, duration_minutes REAL DEFAULT 0, delay_minutes    REAL DEFAULT 0, 
	PRIMARY KEY (id), 
	FOREIGN KEY(activity_id) REFERENCES activities (id)
);
INSERT INTO tasks VALUES(1,'Analye de la demande','',NULL,2,0.0,0.0);
INSERT INTO tasks VALUES(2,'V├®rification de la disponibilit├® catalogue','si catalogue',4,2,0.0,0.0);
INSERT INTO tasks VALUES(3,'Collecte des informations pour les faisabilit├®','Si produit sp├®cifique',7,2,0.0,0.0);
INSERT INTO tasks VALUES(5,'Collecter les informations necessaires','',NULL,4,0.0,0.0);
INSERT INTO tasks VALUES(6,'R├®daction de l''offre','',1,4,0.0,0.0);
INSERT INTO tasks VALUES(8,'Envoie de l''offre','',3,4,0.0,0.0);
INSERT INTO tasks VALUES(9,'Prise en compte de la demande et des objection du client','',NULL,8,0.0,0.0);
INSERT INTO tasks VALUES(10,'Construction d''un argumentaire','',NULL,8,0.0,0.0);
INSERT INTO tasks VALUES(11,'N├®gogiation avec le client ','MArge de n├®go 15 %',NULL,8,0.0,0.0);
INSERT INTO tasks VALUES(12,'V├®rifier avec le client la raison du retard de paiement','',NULL,15,0.0,0.0);
INSERT INTO tasks VALUES(13,'N├®gocier fermement pour obtnir le paiement','Acceptation paiement 30 jours',NULL,15,0.0,0.0);
INSERT INTO tasks VALUES(14,'Identifier l''├®quipe projet','Avec team leader',NULL,5,0.0,0.0);
INSERT INTO tasks VALUES(15,'Pr├®- S├®lectionner les fourniseurs','',NULL,5,0.0,0.0);
INSERT INTO tasks VALUES(17,'Etablir le planning des parties prenantes','',NULL,5,0.0,0.0);
INSERT INTO tasks VALUES(18,'Mesure d''├®cart de r├®sistance','',2,9,0.0,0.0);
INSERT INTO tasks VALUES(19,'Report des r├®sultat sur feuille de test','',NULL,9,0.0,0.0);
INSERT INTO tasks VALUES(20,'Comparaison produits eistants','',1,9,0.0,0.0);
INSERT INTO tasks VALUES(21,'Analyse comparative des fournisseur','France uniquement',1,7,0.0,0.0);
INSERT INTO tasks VALUES(22,'Demande de cotation fournisseurs','',NULL,7,0.0,0.0);
INSERT INTO tasks VALUES(23,'Etablissement d''une feuiller de prix','',2,7,0.0,0.0);
INSERT INTO tasks VALUES(24,'Rapprocher le bon de commande de la facture','V├®rifie fournisseur',NULL,13,0.0,0.0);
INSERT INTO tasks VALUES(25,'Etablir la facture et les pi├¿ces comptables','',1,13,0.0,0.0);
INSERT INTO tasks VALUES(26,'Merttre ├á jour la comptabilit├® clinet','',2,13,0.0,0.0);
INSERT INTO tasks VALUES(27,'Envoyer la facture','',3,13,0.0,0.0);
INSERT INTO tasks VALUES(28,'Pr├®paration des conditions de test','',NULL,11,0.0,0.0);
INSERT INTO tasks VALUES(29,'Ex├®cution des mesures demand├®es','utilisation des instructions',1,11,0.0,0.0);
INSERT INTO tasks VALUES(30,'Etablir les relev├®s de mesure','',2,11,0.0,0.0);
INSERT INTO tasks VALUES(31,'Faire la synth├¿se comparative des mesures','',3,11,0.0,0.0);
INSERT INTO tasks VALUES(32,'Identifier les carac├®ristiques de la demande','',NULL,3,0.0,0.0);
INSERT INTO tasks VALUES(33,'Analyser les contraintes techniques','',3,3,0.0,0.0);
INSERT INTO tasks VALUES(35,'Faire le rapport de faisabilit├®','',9,3,0.0,0.0);
INSERT INTO tasks VALUES(36,'Publication des pages modifi├®es','',13,1,10.0,0.0);
INSERT INTO tasks VALUES(37,'Etablir la liste des relances','',NULL,16,0.0,0.0);
INSERT INTO tasks VALUES(39,'V├®rifier les Ping','',9,1,30.0,0.0);
INSERT INTO tasks VALUES(42, 'Tâche importée manquante', '', NULL, 1, 0, 0);
INSERT INTO tasks VALUES(40,'Faire le comtpe rendu de n├®go','',NULL,8,0.0,0.0);
INSERT INTO tasks VALUES(43,'Traitement des images et photos au format web','',4,1,15.0,0.0);
INSERT INTO tasks VALUES(44,'finalisation de la page savoirs','',NULL,1,20.0,0.0);
INSERT INTO tasks VALUES(46,'Mise en forme de l''offre','En fonction de l''quipe',NULL,4,0.0,0.0);
INSERT INTO tasks VALUES(47,'Informer les personnes','Tous team',NULL,5,0.0,0.0);
INSERT INTO tasks VALUES(48,'Transmettre au ├®quipes','Par mail',NULL,3,0.0,0.0);
CREATE TABLE performances (
	id INTEGER NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	description TEXT, 
	link_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(link_id) REFERENCES links (id) ON DELETE CASCADE, 
	UNIQUE (link_id)
);
INSERT INTO performances VALUES(3,'Respect de la nomenclature','',4);
INSERT INTO performances VALUES(4,'Cotation pr├®pa','',8);
INSERT INTO performances VALUES(5,'Perf feuille de prix','',20);
INSERT INTO performances VALUES(6,'Fine sur feuille de test','',14);
INSERT INTO performances VALUES(7,'Sortie ├®valuation produit','',17);
INSERT INTO performances VALUES(8,'O AMDEC','',NULL);
INSERT INTO performances VALUES(9,'J+1','',27);
INSERT INTO performances VALUES(10,'Avis client','',11);
INSERT INTO performances VALUES(11,'Test info','',13);
INSERT INTO performances VALUES(12,'Pour tous','',16);
INSERT INTO performances VALUES(13,'ave l''├®quipe','',19);
INSERT INTO performances VALUES(14,'J+1 et humour','',26);
INSERT INTO performances VALUES(15,'Sous 24 heures','',1);
INSERT INTO performances VALUES(16,'Sous 8 jour','',6);
INSERT INTO performances VALUES(17,'J + 1','',7);
INSERT INTO performances VALUES(18,'J+1','',2);
INSERT INTO performances VALUES(19,'J+5','',3);
CREATE TABLE task_roles (
	task_id INTEGER NOT NULL, 
	role_id INTEGER NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	PRIMARY KEY (task_id, role_id), 
	FOREIGN KEY(role_id) REFERENCES roles (id), 
	FOREIGN KEY(task_id) REFERENCES tasks (id)
);
INSERT INTO task_roles VALUES(20,14,'R├®alisateur');
INSERT INTO task_roles VALUES(42,14,'Ressource');
INSERT INTO task_roles VALUES(3,3,'Conseil');
INSERT INTO task_roles VALUES(44,13,'R├®alisateur');
INSERT INTO task_roles VALUES(42,13,'Conseil');
INSERT INTO task_roles VALUES(43,13,'Approbateur');
INSERT INTO task_roles VALUES(1,2,'R├®alisateur');
INSERT INTO task_roles VALUES(46,13,'R├®alisateur');
INSERT INTO task_roles VALUES(8,114,'Approbateur');
INSERT INTO task_roles VALUES(17,3,'Approbateur');
INSERT INTO task_roles VALUES(35,3,'Approbateur');
CREATE TABLE task_tools (
	task_id INTEGER NOT NULL, 
	tool_id INTEGER NOT NULL, 
	PRIMARY KEY (task_id, tool_id), 
	FOREIGN KEY(task_id) REFERENCES tasks (id), 
	FOREIGN KEY(tool_id) REFERENCES tools (id)
);
INSERT INTO task_tools VALUES(39,23);
INSERT INTO task_tools VALUES(43,28);
INSERT INTO task_tools VALUES(36,17);
INSERT INTO task_tools VALUES(39,17);
INSERT INTO task_tools VALUES(2,29);
INSERT INTO task_tools VALUES(3,1);
INSERT INTO task_tools VALUES(3,3);
INSERT INTO task_tools VALUES(43,20);
INSERT INTO task_tools VALUES(46,25);
INSERT INTO task_tools VALUES(46,30);
INSERT INTO task_tools VALUES(17,31);
INSERT INTO task_tools VALUES(35,29);
INSERT INTO task_tools VALUES(35,32);
CREATE TABLE IF NOT EXISTS "users" (

    id INTEGER NOT NULL,

    first_name TEXT NOT NULL,

    last_name TEXT NOT NULL,

    age INTEGER,

    email TEXT NOT NULL,

    password TEXT NOT NULL, manager_id INTEGER, status TEXT NOT NULL DEFAULT 'user',

    PRIMARY KEY(id)

);
INSERT INTO users VALUES(0,'Bob','Dupont',40,'bob.dupont@example.com','scrypt:32768:8:1$hashbob',NULL,'user');
INSERT INTO users VALUES(110,'Alice','Bernard',35,'alice.bernard@example.com','scrypt:32768:8:1$Uu2hcSYyaPZoHdPA$47c2a5ffaa44a48733316e321fda9a096c50cb837dd6cd1e82d198493e073479c4f711d50062ce3f945e259abffe2607495472c7d72b139675d0561ddc5b3ba6',114,'administrateur');
INSERT INTO users VALUES(111,'Bob','Dupont',40,'bob.dupont@example.com','scrypt:32768:8:1$YusH80tOxLkLS9vQ$16d1d7abb4820c78560c251d51b192918fa194e7e97cfd19d0db872295b58f1d93233d6005ce4ebc5d2949c0df05362d1e74bc74c1a78c3280d5d1723717c710',114,'user');
INSERT INTO users VALUES(112,'Claude','Moreau',50,'claude.moreau@example.com','scrypt:32768:8:1$randomhash1',114,'user');
INSERT INTO users VALUES(113,'Diana','Leroux',45,'diana.leroux@example.com','scrypt:32768:8:1$randomhash2',NULL,'user');
INSERT INTO users VALUES(114,'Ma├½l','Girardin',20,'mael.pierre.girardin@icloud.com','scrypt:32768:8:1$A5YSvJsMRLWEXgPP$c7e873c503ce0b551ae7e4745b80cf89389f949c5c62faf514008868ce0cc0a444d99a1464282968307285dfc8767476c6f4fa753f34a0d92364bb99d7f979a4',114,'administrateur');
INSERT INTO users VALUES(121,'C├®line','Martin',28,'celine.martin@example.com','scrypt:32768:8:1$hashceline',NULL,'user');
INSERT INTO users VALUES(122,'David','Morin',32,'david.morin@example.com','scrypt:32768:8:1$hashdavid',NULL,'user');
INSERT INTO users VALUES(123,'Eva','Leroy',29,'eva.leroy@example.com','scrypt:32768:8:1$hasheva',NULL,'user');
INSERT INTO users VALUES(124,'Frank','Lemaire',33,'frank.lemaire@example.com','scrypt:32768:8:1$hashfrank',NULL,'user');
INSERT INTO users VALUES(125,'George','Dubois',37,'george.dubois@example.com','scrypt:32768:8:1$hashgeorge',NULL,'user');
INSERT INTO users VALUES(126,'Hanna','Noir',26,'hanna.noir@example.com','scrypt:32768:8:1$hashhanna',114,'user');
INSERT INTO users VALUES(127,'Ibrahim','Khan',31,'ibrahim.khan@example.com','scrypt:32768:8:1$hashibrahim',110,'user');
INSERT INTO users VALUES(128,'Juliette','Fischer',34,'juliette.fischer@example.com','scrypt:32768:8:1$hashjuliette',NULL,'user');
INSERT INTO users VALUES(129,'Kevin','L├®vesque',28,'kevin.levesque@example.com','scrypt:32768:8:1$hashkevin',114,'user');
INSERT INTO users VALUES(130,'Lucie','Simon',29,'lucie.simon@example.com','scrypt:32768:8:1$hashlucie',114,'user');
INSERT INTO users VALUES(131,'Marc','Brun',29,'marc.brun@example.com','scrypt:32768:8:1$hashmarc',NULL,'user');
INSERT INTO users VALUES(201,'Hugette','Bidule',35,'hugette.bidule@example.com','scrypt:32768:8:1$hashalice',NULL,'user');
INSERT INTO users VALUES(203,'Claude','Moreau',50,'claude.moreau@example.com','scrypt:32768:8:1$hashclaude',NULL,'user');
INSERT INTO users VALUES(204,'Diana','Leroux',45,'diana.leroux@example.com','scrypt:32768:8:1$hashdiana',NULL,'user');
INSERT INTO users VALUES(205,'huge','Berne',35,'alice.bernard@example.com','scrypt:...',NULL,'user');
INSERT INTO users VALUES(206,'C├®line','Martin',28,'celine.martin@example.com','scrypt:...',NULL,'user');
INSERT INTO users VALUES(207,'David','Morin',32,'david.morin@example.com','scrypt:...',NULL,'user');
INSERT INTO users VALUES(208,'Eva','Leroy',29,'eva.leroy@example.com','scrypt:...',NULL,'user');
INSERT INTO users VALUES(209,'Frank','Lemaire',33,'frank.lemaire@example.com','scrypt:...',NULL,'user');
INSERT INTO users VALUES(210,'evannn','cikacz',20,'evan.cikacz@orange.fr','scrypt:32768:8:1$ILTE19xbNMhlmaFn$21e2491a552c4f39b8d7b2a4099658d87324b9d5139e3582255ae1cbe3a32f42c89ee22843a459d21732c0a8ac78e5de0d3390db97427af7dd2ab70c3c57a675',NULL,'user');
INSERT INTO users VALUES(211,'Hubert','GRANDJEAN',21,'h.grandjean@afdec.fr','123456',114,'administrateur');
INSERT INTO users VALUES(212,'test','test',20,'mael.pierre.girardin@icloud.com','123456',NULL,'user');
INSERT INTO users VALUES(213, 'Import', '213',  null, 'import213@example.com', '123456', null, 'user');
INSERT INTO users VALUES(214, 'Import', '214',  null, 'import214@example.com', '123456', null, 'user');
CREATE TABLE user_roles (

    user_id INTEGER NOT NULL,

    role_id INTEGER NOT NULL,

    PRIMARY KEY (user_id, role_id),

    FOREIGN KEY(user_id) REFERENCES users(id),

    FOREIGN KEY(role_id) REFERENCES roles(id)

);
INSERT INTO user_roles VALUES(114,1);
INSERT INTO user_roles VALUES(112,10);
INSERT INTO user_roles VALUES(210,1);
INSERT INTO user_roles VALUES(211,19);
INSERT INTO user_roles VALUES(212,1);
INSERT INTO user_roles VALUES(211,20);
INSERT INTO user_roles VALUES(213,1);
INSERT INTO user_roles VALUES(214,1);
INSERT INTO user_roles VALUES(211,1);
INSERT INTO user_roles VALUES(212,17);
INSERT INTO user_roles VALUES(212,9);
INSERT INTO user_roles VALUES(212,19);
INSERT INTO user_roles VALUES(201,15);
INSERT INTO user_roles VALUES(201,22);
INSERT INTO user_roles VALUES(131,5);
INSERT INTO user_roles VALUES(111,7);
INSERT INTO user_roles VALUES(111,3);
INSERT INTO user_roles VALUES(111,4);
INSERT INTO user_roles VALUES(111,15);
INSERT INTO user_roles VALUES(111,2);
INSERT INTO user_roles VALUES(111,13);
INSERT INTO user_roles VALUES(110,17);
INSERT INTO user_roles VALUES(110,16);
INSERT INTO user_roles VALUES(110,114);
INSERT INTO user_roles VALUES(110,11);
INSERT INTO user_roles VALUES(110,12);
INSERT INTO user_roles VALUES(110,13);
INSERT INTO user_roles VALUES(129,10);
INSERT INTO user_roles VALUES(205,2);
CREATE TABLE competency_evaluation (

    id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

    user_id INTEGER NOT NULL,

    activity_id INTEGER NOT NULL,

    item_id INTEGER,

    item_type VARCHAR(50), -- 'savoirs', 'savoir_faires', 'softskills', ou NULL pour la synth├¿se

    eval_number VARCHAR(50), -- '1', '2', '3' pour les 3 temps OU 'garant'/'manager'/'rh' pour synth├¿se

    note VARCHAR(10) NOT NULL,

    created_at TEXT DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(user_id, activity_id, item_id, item_type, eval_number),

    FOREIGN KEY(user_id) REFERENCES users(id),

    FOREIGN KEY(activity_id) REFERENCES activities(id)

);
INSERT INTO competency_evaluation VALUES(1,111,1,5,'savoirs','1','red','2025-08-15 12:45:48.832369');
INSERT INTO competency_evaluation VALUES(2,111,1,5,'savoirs','2','orange','2025-08-15 12:45:48.833364');
INSERT INTO competency_evaluation VALUES(3,111,1,5,'savoirs','3','green','2025-08-15 12:45:48.835142');
INSERT INTO competency_evaluation VALUES(4,111,1,6,'savoirs','1','red','2025-08-15 12:45:48.836198');
INSERT INTO competency_evaluation VALUES(5,111,1,6,'savoirs','2','orange','2025-08-15 12:45:48.837198');
INSERT INTO competency_evaluation VALUES(6,111,1,6,'savoirs','3','orange','2025-08-15 12:45:48.838200');
INSERT INTO competency_evaluation VALUES(7,111,1,3,'savoir_faires','1','red','2025-08-15 12:45:48.844222');
INSERT INTO competency_evaluation VALUES(8,111,1,3,'savoir_faires','2','red','2025-08-15 12:45:48.845226');
INSERT INTO competency_evaluation VALUES(9,111,1,3,'savoir_faires','3','green','2025-08-15 12:45:48.846227');
INSERT INTO competency_evaluation VALUES(10,111,1,4,'savoir_faires','1','red','2025-08-15 12:45:48.847221');
INSERT INTO competency_evaluation VALUES(11,111,1,4,'savoir_faires','2','orange','2025-08-15 12:45:48.848737');
INSERT INTO competency_evaluation VALUES(12,111,1,4,'savoir_faires','3','orange','2025-08-15 12:45:48.849078');
INSERT INTO competency_evaluation VALUES(13,111,1,5,'savoir_faires','1','orange','2025-08-15 12:45:48.850177');
INSERT INTO competency_evaluation VALUES(14,111,1,5,'savoir_faires','2','red','2025-08-15 12:45:48.851179');
INSERT INTO competency_evaluation VALUES(15,111,1,5,'savoir_faires','3','red','2025-08-15 12:45:48.852181');
INSERT INTO competency_evaluation VALUES(16,111,1,6,'savoir_faires','1','green','2025-08-15 12:45:48.853179');
INSERT INTO competency_evaluation VALUES(17,111,1,6,'savoir_faires','2','green','2025-08-15 12:45:48.854179');
INSERT INTO competency_evaluation VALUES(18,111,1,6,'savoir_faires','3','green','2025-08-15 12:45:48.855979');
INSERT INTO competency_evaluation VALUES(19,111,1,7,'savoir_faires','1','orange','2025-08-15 12:45:48.856036');
INSERT INTO competency_evaluation VALUES(20,111,1,7,'savoir_faires','2','orange','2025-08-15 12:45:48.857139');
INSERT INTO competency_evaluation VALUES(21,111,1,7,'savoir_faires','3','green','2025-08-15 12:45:48.858136');
INSERT INTO competency_evaluation VALUES(22,111,1,8,'savoir_faires','1','orange','2025-08-15 12:45:48.860135');
INSERT INTO competency_evaluation VALUES(23,111,1,8,'savoir_faires','2','orange','2025-08-15 12:45:48.861135');
INSERT INTO competency_evaluation VALUES(24,111,1,8,'savoir_faires','3','orange','2025-08-15 12:45:48.862139');
INSERT INTO competency_evaluation VALUES(25,111,1,116,'softskills','1','red','2025-05-28 15:37:08.284222');
INSERT INTO competency_evaluation VALUES(26,111,1,116,'softskills','2','red','2025-05-28 15:37:08.284222');
INSERT INTO competency_evaluation VALUES(27,111,1,116,'softskills','3','orange','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(28,111,1,117,'softskills','1','red','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(29,111,1,117,'softskills','2','orange','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(30,111,1,117,'softskills','3','green','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(31,111,1,118,'softskills','1','red','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(32,111,1,118,'softskills','2','orange','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(33,111,1,118,'softskills','3','orange','2025-05-28 15:37:08.300058');
INSERT INTO competency_evaluation VALUES(34,111,1,119,'softskills','1','green','2025-05-28 15:37:08.315915');
INSERT INTO competency_evaluation VALUES(35,111,1,119,'softskills','2','orange','2025-05-28 15:37:08.317925');
INSERT INTO competency_evaluation VALUES(36,111,1,119,'softskills','3','green','2025-05-28 15:37:08.317925');
INSERT INTO competency_evaluation VALUES(37,111,1,NULL,NULL,'garant','green','2025-08-15 12:45:48.869816');
INSERT INTO competency_evaluation VALUES(38,111,1,NULL,NULL,'manager','green','2025-08-15 12:45:48.870973');
INSERT INTO competency_evaluation VALUES(39,111,1,NULL,NULL,'rh','orange','2025-09-11 22:57:20.358016');
INSERT INTO competency_evaluation VALUES(40,111,3,NULL,NULL,'manager','orange','2025-08-15 12:45:48.817671');
INSERT INTO competency_evaluation VALUES(41,111,4,NULL,NULL,'manager','green','2025-08-15 12:45:48.820986');
INSERT INTO competency_evaluation VALUES(42,111,5,NULL,NULL,'manager','orange','2025-05-28 15:37:08.160024');
INSERT INTO competency_evaluation VALUES(43,111,2,NULL,NULL,'manager','red','2025-08-15 12:45:48.814569');
INSERT INTO competency_evaluation VALUES(44,111,7,NULL,NULL,'garant','green','2025-08-15 12:45:48.880970');
INSERT INTO competency_evaluation VALUES(45,111,7,NULL,NULL,'manager','green','2025-08-15 12:45:48.881972');
INSERT INTO competency_evaluation VALUES(46,111,4,104,'softskills','1','red','2025-05-28 15:37:08.331685');
INSERT INTO competency_evaluation VALUES(47,111,4,104,'softskills','2','red','2025-05-28 15:37:08.331685');
INSERT INTO competency_evaluation VALUES(48,111,4,104,'softskills','3','red','2025-05-28 15:37:08.331685');
INSERT INTO competency_evaluation VALUES(49,111,3,NULL,NULL,'garant','green','2025-08-15 12:45:48.816677');
INSERT INTO competency_evaluation VALUES(50,111,3,NULL,NULL,'rh','red','2025-08-15 12:45:48.818675');
INSERT INTO competency_evaluation VALUES(51,111,4,NULL,NULL,'garant','red','2025-08-15 12:45:48.819669');
INSERT INTO competency_evaluation VALUES(52,111,4,NULL,NULL,'rh','red','2025-08-15 12:45:48.821471');
INSERT INTO competency_evaluation VALUES(53,111,5,NULL,NULL,'garant','green','2025-05-28 15:37:08.152513');
INSERT INTO competency_evaluation VALUES(54,111,4,103,'softskills','1','red','2025-05-28 15:37:08.317925');
INSERT INTO competency_evaluation VALUES(55,111,4,103,'softskills','2','red','2025-05-28 15:37:08.331685');
INSERT INTO competency_evaluation VALUES(56,111,4,103,'softskills','3','red','2025-05-28 15:37:08.331685');
INSERT INTO competency_evaluation VALUES(57,111,4,105,'softskills','1','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(58,111,4,105,'softskills','2','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(59,111,4,105,'softskills','3','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(60,111,4,106,'softskills','1','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(61,111,4,106,'softskills','2','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(62,111,4,106,'softskills','3','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(63,111,4,107,'softskills','1','red','2025-05-28 15:37:08.347570');
INSERT INTO competency_evaluation VALUES(64,111,4,107,'softskills','2','red','2025-05-28 15:37:08.364962');
INSERT INTO competency_evaluation VALUES(65,111,4,107,'softskills','3','red','2025-05-28 15:37:08.364962');
INSERT INTO competency_evaluation VALUES(66,111,7,NULL,NULL,'rh','red','2025-08-15 12:53:52.464392');
INSERT INTO competency_evaluation VALUES(67,111,5,NULL,NULL,'rh','green','2025-05-30 11:40:27.601411');
INSERT INTO competency_evaluation VALUES(68,111,2,NULL,NULL,'garant','red','2025-08-15 12:45:48.810719');
INSERT INTO competency_evaluation VALUES(69,111,2,NULL,NULL,'rh','red','2025-08-15 12:45:48.815678');
INSERT INTO competency_evaluation VALUES(70,111,6,NULL,NULL,'garant','orange','2025-08-15 12:45:48.822577');
INSERT INTO competency_evaluation VALUES(71,111,6,NULL,NULL,'manager','orange','2025-08-15 12:45:48.823583');
INSERT INTO competency_evaluation VALUES(72,111,6,NULL,NULL,'rh','orange','2025-08-15 12:45:48.824585');
INSERT INTO competency_evaluation VALUES(73,111,10,NULL,NULL,'garant','red','2025-08-15 12:45:48.825586');
INSERT INTO competency_evaluation VALUES(74,111,10,NULL,NULL,'manager','red','2025-08-15 12:45:48.826587');
INSERT INTO competency_evaluation VALUES(75,111,10,NULL,NULL,'rh','red','2025-08-15 12:45:48.828212');
INSERT INTO competency_evaluation VALUES(76,111,16,NULL,NULL,'garant','green','2025-08-15 12:45:48.872962');
INSERT INTO competency_evaluation VALUES(77,111,16,NULL,NULL,'manager','green','2025-08-15 12:45:48.873968');
INSERT INTO competency_evaluation VALUES(78,111,2,NULL,'activities','manager','red','2025-08-15 12:45:48.884885');
INSERT INTO competency_evaluation VALUES(79,111,3,NULL,'activities','manager','orange','2025-08-15 12:45:48.887887');
INSERT INTO competency_evaluation VALUES(80,111,4,NULL,'activities','manager','green','2025-08-15 12:45:48.888885');
INSERT INTO competency_evaluation VALUES(81,111,6,NULL,'activities','manager','orange','2025-08-15 12:45:48.890565');
INSERT INTO competency_evaluation VALUES(82,111,10,NULL,'activities','manager','red','2025-08-15 12:45:48.891714');
INSERT INTO competency_evaluation VALUES(83,111,16,NULL,'activities','manager','green','2025-08-15 12:45:48.892727');
INSERT INTO competency_evaluation VALUES(84,111,7,NULL,'activities','manager','green','2025-08-15 12:45:48.893722');
INSERT INTO competency_evaluation VALUES(85,111,1,NULL,'activities','manager','green','2025-08-15 12:45:48.894728');
INSERT INTO competency_evaluation VALUES(86,111,1,4,'savoirs','2','green','2025-09-11 22:53:25.829435');
INSERT INTO competency_evaluation VALUES(87,111,1,12,'savoirs','1','red','2025-09-11 23:49:43.157883');
INSERT INTO competency_evaluation VALUES(88,111,1,12,'savoirs','2','red','2025-09-11 23:49:43.157883');
INSERT INTO competency_evaluation VALUES(89,111,1,12,'savoirs','3','red','2025-09-11 23:49:43.157883');
INSERT INTO competency_evaluation VALUES(90,111,1,7,'savoirs','2','red','2025-09-12 07:41:58.497292');
INSERT INTO competency_evaluation VALUES(91,111,1,3,'savoirs','2','orange','2025-09-12 17:02:01.185062');
CREATE TABLE IF NOT EXISTS "user_competencies" (

    "user_id" INTEGER NOT NULL,

    "competency_id" INTEGER NOT NULL,

    "evaluation_date" DATE NOT NULL,

    "self_assessment" INTEGER CHECK (self_assessment BETWEEN 1 AND 3),

    PRIMARY KEY("user_id", "competency_id", "evaluation_date"),

    FOREIGN KEY("user_id") REFERENCES "users"("id"),

    FOREIGN KEY("competency_id") REFERENCES "competencies"("id")

);
INSERT INTO user_competencies VALUES(121,15,'2023-10-01',2);
INSERT INTO user_competencies VALUES(122,16,'2023-10-01',1);
INSERT INTO user_competencies VALUES(123,17,'2023-10-01',3);
INSERT INTO user_competencies VALUES(124,18,'2023-10-01',1);
INSERT INTO user_competencies VALUES(125,19,'2023-10-01',2);
INSERT INTO user_competencies VALUES(126,20,'2023-10-01',3);
INSERT INTO user_competencies VALUES(127,16,'2023-10-01',1);
INSERT INTO user_competencies VALUES(128,17,'2023-10-01',2);
INSERT INTO user_competencies VALUES(129,18,'2023-10-01',1);
CREATE TABLE entreprise_settings (

    id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

    work_hours_per_day INTEGER,

    work_days_per_week INTEGER,

    work_weeks_per_year INTEGER,

    work_days_per_year INTEGER

);
INSERT INTO entreprise_settings VALUES(1,7,5,42,NULL);
CREATE TABLE manager_assignments (

    manager_id INTEGER NOT NULL,

    user_id INTEGER NOT NULL,

    role_id INTEGER, -- NULL si global (tous les r├┤les)

    PRIMARY KEY (manager_id, user_id, role_id),

    FOREIGN KEY (manager_id) REFERENCES users(id),

    FOREIGN KEY (user_id) REFERENCES users(id),

    FOREIGN KEY (role_id) REFERENCES roles(id)

);
CREATE TABLE time_analysis (

    id INTEGER PRIMARY KEY,

    duration INTEGER NOT NULL,

    recurrence TEXT NOT NULL,

    frequency INTEGER NOT NULL,

    delay INTEGER,

    type TEXT NOT NULL,

    activity_id INTEGER,

    task_id INTEGER,

    nb_people INTEGER NOT NULL DEFAULT 1,

    impact_unit TEXT,

    delay_increase REAL,

    delay_percentage REAL,

    role_id INTEGER,

    user_id INTEGER,

    FOREIGN KEY (activity_id) REFERENCES activities(id),

    FOREIGN KEY (task_id) REFERENCES tasks(id),

    FOREIGN KEY (role_id) REFERENCES roles(id),

    FOREIGN KEY (user_id) REFERENCES users(id)

);
INSERT INTO time_analysis VALUES(2,1,'journalier',3,2,'user',1,NULL,1,'minutes',3.0,NULL,1,212);
INSERT INTO time_analysis VALUES(3,45,'hebdo',2,20,'role',1,NULL,1,'minutes',30.0,NULL,1,0);
INSERT INTO time_analysis VALUES(7,240,'hebdomadaire',4,NULL,'activity',1,NULL,3,'minutes',NULL,NULL,NULL,NULL);
INSERT INTO time_analysis VALUES(8,180,'hebdomadaire',2,NULL,'activity',15,NULL,1,'minutes',NULL,NULL,NULL,NULL);
CREATE TABLE performance_personnalisee (

    id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

    user_id INTEGER NOT NULL,

    activity_id INTEGER NOT NULL,

    content TEXT,

    created_at TEXT,

    updated_at TEXT,

    deleted BOOLEAN DEFAULT FALSE

, validation_status TEXT NOT NULL DEFAULT 'non-valid├®e', validation_date TEXT);
INSERT INTO performance_personnalisee VALUES(1,111,1,'testee','2025-06-17T17:00:25.362172','2025-06-24 13:49:36.850498',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(4,111,16,'bonjour','2025-06-18 08:57:32.866051','2025-10-01T13:57:36.490369',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(5,111,2,'test','2025-06-18 10:30:55.884103','2025-06-18 11:04:57.317083',false,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(6,111,4,'oui','2025-06-18 10:59:58.864398','2025-06-18 10:59:58.864398',false,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(7,111,16,'test','2025-06-19 10:00:33.379176','2025-06-19 10:00:43.423156',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(8,111,16,'testtttt','2025-06-19 11:06:43.503568','2025-06-19 11:06:45.238225',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(9,111,16,'cccc','2025-06-19 11:07:07.534647','2025-10-01T11:21:07.476686',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(10,111,16,'aaaaa','2025-06-19 11:07:12.821792','2025-10-01T11:21:04.398270',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(11,111,16,'ssssssssss','2025-06-19 11:07:16.195679','2025-10-01T10:44:20.992989',true,'non-valid├®e',NULL);
INSERT INTO performance_personnalisee VALUES(12,111,16,'test 2 1/10/25','2025-06-19 11:07:21.126379','2025-10-01T13:24:46.689929',true,'validee','2025-10-01');
INSERT INTO performance_personnalisee VALUES(13,111,1,'respect de la nomenclature de base (d├®butant).','2025-06-24 13:49:14.656905','2025-10-01T13:03:59.194074',false,'validee','2025-10-01');
INSERT INTO performance_personnalisee VALUES(14,111,1,'test','2025-10-01T10:23:32.907707','2025-10-01T10:23:46.353633',true,'non-validee','2025-10-01');
INSERT INTO performance_personnalisee VALUES(15,111,16,'Bonjour tout le monde !!','2025-10-01T11:52:56.127255','2025-10-01T13:23:59.041912',false,'validee','2025-10-01');
INSERT INTO performance_personnalisee VALUES(16,111,16,'en bien de','2025-10-01T13:25:05.156366','2025-10-01T13:44:09.102841',false,'validee','2025-10-01');
INSERT INTO performance_personnalisee VALUES(17,111,16,'test suppr','2025-10-01T13:58:06.284196','2025-10-01T13:58:16.327810',true,'non-validee','2025-10-01');
INSERT INTO performance_personnalisee VALUES(18,111,16,'testtest','2025-10-01T14:20:50.346910','2025-10-01T14:21:23.660230',true,'non-validee','2025-10-01');
CREATE TABLE performance_personnalisee_historique (

    id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

    performance_id INTEGER NOT NULL,

    contenu TEXT,

    validation_status TEXT,

    validation_date TEXT,

    changed_at TEXT NOT NULL DEFAULT (now()),

    changed_by INTEGER, event TEXT, content TEXT, user_id INTEGER, activity_id INTEGER,

    FOREIGN KEY (performance_id) REFERENCES performance_personnalisee(id)

);
INSERT INTO performance_personnalisee_historique VALUES(1,13,'respect de la nomenclature de base (d├®butant)',NULL,NULL,'2025-09-12 09:19:25',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(2,14,'test 23',NULL,NULL,'2025-09-12 11:12:05',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(3,14,'te',NULL,NULL,'2025-09-12 11:12:21',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(4,13,'respect de la nomenclature de base (d├®butant)',NULL,NULL,'2025-09-12 16:54:23',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(5,13,'respect de la nomenclature de base (d├®butant)',NULL,NULL,'2025-09-12 17:03:00',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(6,13,'respect de la nomenclature de base (d├®butant) fin',NULL,NULL,'2025-09-12 17:03:26',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(7,13,'respect de la nomenclature de base (d├®butant)',NULL,NULL,'2025-09-12 17:03:29',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(8,14,'test perf 01/10/25',NULL,NULL,'2025-10-01 09:21:14',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(11,14,'test',NULL,NULL,'2025-10-01 09:31:55',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(12,12,'ffffff',NULL,NULL,'2025-10-01 10:02:00',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(13,11,'ssssssssss',NULL,NULL,'2025-10-01 10:02:02',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(14,10,'aaaaa',NULL,NULL,'2025-10-01 10:02:05',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(15,9,'cccc',NULL,NULL,'2025-10-01 10:02:07',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(16,14,'test',NULL,NULL,'2025-10-01 10:02:19',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(17,12,'ffffff',NULL,NULL,'2025-10-01 10:02:39',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(18,11,'ssssssssss',NULL,NULL,'2025-10-01 10:03:15',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(19,9,'cccc',NULL,NULL,'2025-10-01 10:03:18',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(20,10,'aaaaa',NULL,NULL,'2025-10-01 10:03:20',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(21,12,'ffffff',NULL,NULL,'2025-10-01 10:03:22',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(22,14,'test',NULL,NULL,'2025-10-01 10:03:29',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(23,13,'respect de la nomenclature de base (d├®butant)',NULL,NULL,'2025-10-01 10:05:14',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(24,13,'respect de la nomenclature de base (d├®butant)',NULL,NULL,'2025-10-01 10:23:11',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(25,14,'test',NULL,NULL,'2025-10-01 10:23:32',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(26,14,'test',NULL,NULL,'2025-10-01 10:23:46',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(27,11,'ssssssssss',NULL,NULL,'2025-10-01 10:44:21',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(28,12,'ffffff',NULL,NULL,'2025-10-01 10:44:27',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(29,10,'aaaaa',NULL,NULL,'2025-10-01 11:21:04',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(30,9,'cccc',NULL,NULL,'2025-10-01 11:21:07',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(31,12,'test 2 1/10/25',NULL,NULL,'2025-10-01 11:21:29',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(32,13,'respect de la nomenclature de base (d├®butant).',NULL,NULL,'2025-10-01 11:36:19',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(33,12,'test 2 1/10/250',NULL,NULL,'2025-10-01 11:37:18',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(34,12,'test 2 1/10/25',NULL,NULL,'2025-10-01 11:37:26',NULL,NULL,NULL,NULL,NULL);
INSERT INTO performance_personnalisee_historique VALUES(35,13,NULL,'validee','2025-10-01','2025-10-01 11:47:27',NULL,'before_update','respect de la nomenclature de base (d├®butant) tete.',111,1);
INSERT INTO performance_personnalisee_historique VALUES(38,15,NULL,'non-validee','2025-10-01','2025-10-01 11:52:56',NULL,'created','Bonjour',111,16);
INSERT INTO performance_personnalisee_historique VALUES(39,15,NULL,'non-validee','2025-10-01','2025-10-01 11:53:06',NULL,'before_update','Bonjour',111,16);
INSERT INTO performance_personnalisee_historique VALUES(40,13,NULL,'validee','2025-10-01','2025-10-01 12:52:39',NULL,'before_update','respect de la nomenclature de base (d├®butant).',111,1);
INSERT INTO performance_personnalisee_historique VALUES(41,13,NULL,'validee','2025-10-01','2025-10-01 13:03:59',NULL,'before_update','respect de la nomenclature de base (d├®butant). test 2',111,1);
INSERT INTO performance_personnalisee_historique VALUES(42,15,NULL,'non-validee','2025-10-01','2025-10-01 13:11:55',NULL,'before_update','Bonjour.',111,16);
INSERT INTO performance_personnalisee_historique VALUES(43,15,NULL,'non-validee','2025-10-01','2025-10-01 13:23:59',NULL,'before_update','Bonjour tout le monde !!',111,16);
INSERT INTO performance_personnalisee_historique VALUES(44,12,NULL,'validee','2025-10-01','2025-10-01 13:24:46',NULL,'deleted','test 2 1/10/25',111,16);
CREATE TABLE prerequis_comment (

    id              INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

    user_id         INTEGER NOT NULL,              -- collaborateur ├®valu├®

    activity_id     INTEGER NOT NULL,

    item_type       TEXT NOT NULL CHECK(item_type IN ('savoir','savoir_faire','hsc')),

    item_id         INTEGER NOT NULL,              -- id de lÔÇÖitem (table savoirs/savoir_faire/hsc)

    comment         TEXT,                          -- commentaire libre du manager

    created_at      TEXT DEFAULT (now()),

    updated_at      TEXT

);
INSERT INTO prerequis_comment VALUES(411,111,1,'savoir',3,'autonomie','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(412,111,1,'savoir',4,'d├®tient les bases','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(413,111,1,'savoir',5,'autonomie','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(414,111,1,'savoir',6,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(415,111,1,'savoir',8,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(416,111,1,'savoir',22,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(417,111,1,'savoir_faire',3,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(418,111,1,'savoir_faire',6,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(419,111,1,'savoir_faire',8,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(420,111,1,'hsc',126,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(421,111,1,'hsc',127,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(422,111,1,'hsc',128,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(423,111,1,'hsc',129,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
INSERT INTO prerequis_comment VALUES(424,111,1,'hsc',130,'','2025-10-01 15:21:59','2025-10-01T15:21:59.271317');
CREATE TABLE training_plan (

    id              INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

    user_id         INTEGER NOT NULL,  -- collaborateur

    role_id         INTEGER NOT NULL,

    activity_id     INTEGER NOT NULL,

    plan_type       TEXT NOT NULL,     -- "PLAN_DE_FORMATION" | "PLAN_D_ACCOMPAGNEMENT_COMPETENCE" | "FEEDBACK_DE_MAINTIEN"

    plan_json       TEXT NOT NULL,     -- JSON complet (sch├®ma du prompt)

    created_at      TEXT DEFAULT (now())

);
INSERT INTO training_plan VALUES(1,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les t├óches.\",\n        \"methode\": \"Atelier pratique sur la gestion autonome des projets.\",\n        \"livrables\": \"Rapport d''auto-├®valuation et plan d''action personnel.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S1 - S2\",\n        \"criteres_validation\": \"├ëvaluation de l''autonomie par le manager.\",\n        \"jalons\": {\n          \"S2\": \"Fin de l''atelier et remise des rapports.\"\n        }\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs techniques.\",\n        \"methode\": \"Micro-learning sur les fondamentaux techniques.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S3\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\",\n        \"jalons\": {\n          \"S4\": \"├ëvaluation des r├®sultats du quiz.\"\n        }\n      }\n    ],\n    \"echancier\": {\n      \"S1\": \"D├®but de l''atelier sur l''autonomie.\",\n      \"S2\": \"Fin de l''atelier et remise des rapports.\",\n      \"S3\": \"D├®but du micro-learning.\",\n      \"S4\": \"├ëvaluation des r├®sultats du quiz.\",\n      \"S8\": \"Suivi des progr├¿s et ajustements si n├®cessaires.\"\n    }\n  }\n}\n```"}}','2025-09-16 22:05:12');
INSERT INTO training_plan VALUES(2,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les t├óches\",\n        \"methode\": \"Atelier pratique avec mise en situation\",\n        \"livrables\": \"Rapport de progression\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation de l''autonomie par le manager\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs sp├®cifiques\",\n        \"methode\": \"Micro-learning sur les fondamentaux\",\n        \"livrables\": \"Quiz de validation\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire pratiques\",\n        \"methode\": \"Coaching individuel\",\n        \"livrables\": \"Plan d''action personnalis├®\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S3-S4\",\n        \"criteres_validation\": \"Feedback positif du coach\"\n      },\n      {\n        \"objectif\": \"Renforcer les HSC\",\n        \"methode\": \"Atelier collaboratif\",\n        \"livrables\": \"Guide de bonnes pratiques\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S5-S6\",\n        \"criteres_validation\": \"├ëvaluation des pratiques par le manager\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Atelier pratique et micro-learning\",\n      \"S4\": \"Coaching et ├®valuation interm├®diaire\",\n      \"S6\": \"Atelier collaboratif et validation des HSC\"\n    }\n  }\n}\n```"}}','2025-09-16 22:09:17');
INSERT INTO training_plan VALUES(3,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Renforcer l''autonomie dans les t├óches quotidiennes\",\n        \"methode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progr├¿s sur l''autonomie\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S1 - S2\",\n        \"criteres_validation\": \"Am├®lioration de l''autonomie mesur├®e par des feedbacks r├®guliers\"\n      },\n      {\n        \"objectif\": \"Acqu├®rir des connaissances de base sur les processus\",\n        \"methode\": \"Atelier pratique\",\n        \"livrables\": \"Certificat de participation et ├®valuation des connaissances\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S3 - S4\",\n        \"criteres_validation\": \"Score d''├®valuation sup├®rieur ├á 80%\"\n      },\n      {\n        \"objectif\": \"D├®velopper les comp├®tences sp├®cifiques li├®es aux savoir-faire\",\n        \"methode\": \"Micro-learning avec modules en ligne\",\n        \"livrables\": \"Suivi des modules compl├®t├®s\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S5 - S6\",\n        \"criteres_validation\": \"Ach├¿vement de tous les modules avec un score d''├®valuation sup├®rieur ├á 75%\"\n      },\n      {\n        \"objectif\": \"Renforcer les HSC n├®cessaires pour le r├┤le\",\n        \"methode\": \"Compagnonnage avec un mentor\",\n        \"livrables\": \"Journal de bord des sessions de compagnonnage\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S7 - S8\",\n        \"criteres_validation\": \"Feedback positif du mentor sur l''application des HSC\"\n      }\n    ],\n    \"echeancier\": {\n      \"S2\": \"Fin de la premi├¿re phase de coaching\",\n      \"S4\": \"Fin de l''atelier pratique\",\n      \"S8\": \"Fin du plan de formation avec validation des comp├®tences\"\n    }\n  }\n}\n```"}}','2025-09-16 22:23:47');
INSERT INTO training_plan VALUES(4,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Renforcer l''autonomie dans les t├óches\",\n        \"methode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progr├¿s\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Am├®lioration de l''autonomie mesur├®e par des retours d''exp├®rience\",\n        \"jalon\": \"S2\"\n      },\n      {\n        \"objectif\": \"Acqu├®rir des bases solides dans les savoirs manquants\",\n        \"methode\": \"Atelier pratique\",\n        \"livrables\": \"Certificat de participation\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"├ëvaluation des connaissances acquises via un test\",\n        \"jalon\": \"S4\"\n      },\n      {\n        \"objectif\": \"Renforcer les savoir-faire sp├®cifiques\",\n        \"methode\": \"Micro-learning\",\n        \"livrables\": \"Module de formation en ligne\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S8\",\n        \"criteres_validation\": \"Feedback sur l''application des savoir-faire dans le travail quotidien\",\n        \"jalon\": \"S8\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Coaching individuel sur l''autonomie\",\n      \"S4\": \"Atelier pratique sur les bases des savoirs\",\n      \"S8\": \"Module de micro-learning sur les savoir-faire\"\n    }\n  }\n}\n```"}}','2025-10-01 09:10:49');
INSERT INTO training_plan VALUES(5,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs\",\n        \"m├®thode\": \"Atelier pratique\",\n        \"livrables\": \"Guide d''autonomie\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation de l''autonomie par un quiz\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs\",\n        \"m├®thode\": \"Micro-learning\",\n        \"livrables\": \"Modules de formation en ligne\",\n        \"dur├®e_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Test de connaissances\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire sp├®cifiques\",\n        \"m├®thode\": \"Coaching individuel\",\n        \"livrables\": \"Plan de d├®veloppement personnel\",\n        \"dur├®e_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback du coach\"\n      },\n      {\n        \"objectif\": \"Am├®liorer les HSC\",\n        \"m├®thode\": \"Atelier collaboratif\",\n        \"livrables\": \"Plan d''action HSC\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S8\",\n        \"criteres_validation\": \"├ëvaluation des HSC par les pairs\"\n      }\n    ],\n    \"echeancier\": {\n      \"S2\": \"Ateliers et modules de formation\",\n      \"S4\": \"Coaching et feedback\",\n      \"S8\": \"├ëvaluation finale et ajustements\"\n    }\n  }\n}\n```"}}','2025-10-01 13:06:01');
INSERT INTO training_plan VALUES(6,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs identifi├®s\",\n        \"methode\": \"Atelier pratique sur les savoirs sp├®cifiques\",\n        \"livrables\": \"Rapport d''atelier et ├®valuation des comp├®tences\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation des comp├®tences acquises par un test pratique\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs\",\n        \"methode\": \"Micro-learning sur les fondamentaux\",\n        \"livrables\": \"Modules de micro-learning compl├®t├®s\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Quiz de validation des connaissances\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire pratiques\",\n        \"methode\": \"Coaching individuel avec un expert\",\n        \"livrables\": \"Plan de d├®veloppement personnel et feedback\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback du coach sur les progr├¿s r├®alis├®s\"\n      },\n      {\n        \"objectif\": \"├ëvaluer et ajuster les comp├®tences HSC\",\n        \"methode\": \"S├®ance de compagnonnage\",\n        \"livrables\": \"Rapport d''├®valuation des HSC\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S8\",\n        \"criteres_validation\": \"├ëvaluation des HSC par le manager\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning\",\n      \"S4\": \"Coaching et suivi\",\n      \"S8\": \"├ëvaluation finale\"\n    }\n  }\n}\n```"}}','2025-10-01 14:54:25');
INSERT INTO training_plan VALUES(7,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs identifi├®s.\",\n        \"methode\": \"Atelier pratique sur les savoirs sp├®cifiques.\",\n        \"livrables\": \"Rapport d''├®valuation des comp├®tences acquises.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation positive des comp├®tences par le formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"methode\": \"Micro-learning sur les fondamentaux.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire sp├®cifiques.\",\n        \"methode\": \"Coaching individuel avec un expert.\",\n        \"livrables\": \"Plan d''action personnalis├®.\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback positif de l''expert sur les progr├¿s r├®alis├®s.\"\n      }\n    ],\n    \"echeancier\": {\n      \"S2\": \"Ateliers et micro-learning\",\n      \"S4\": \"Coaching individuel\",\n      \"S8\": \"├ëvaluation finale des comp├®tences.\"\n    }\n  }\n}\n```"}}','2025-10-01 15:04:46');
INSERT INTO training_plan VALUES(8,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs identifi├®s.\",\n        \"methode\": \"Atelier pratique sur les savoirs sp├®cifiques.\",\n        \"livrables\": \"Rapport d''atelier et ├®valuation des comp├®tences.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation positive des participants sur l''autonomie.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"methode\": \"Micro-learning sur les concepts fondamentaux.\",\n        \"livrables\": \"Modules de micro-learning compl├®t├®s.\",\n        \"duree_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% sur les quiz de fin de module.\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire pratiques.\",\n        \"methode\": \"Coaching individuel avec un mentor.\",\n        \"livrables\": \"Feedback du mentor et plan d''action personnel.\",\n        \"duree_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Am├®lioration mesurable dans les t├óches pratiques.\"\n      },\n      {\n        \"objectif\": \"Renforcer les HSC.\",\n        \"methode\": \"Atelier collaboratif sur les HSC.\",\n        \"livrables\": \"Guide pratique sur les HSC.\",\n        \"duree_estimee\": \"2 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"├ëvaluation des participants sur la mise en pratique des HSC.\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning\",\n      \"S4\": \"Coaching et ateliers HSC\",\n      \"S8\": \"├ëvaluation finale et feedback\"\n    }\n  }\n}\n```"}}','2025-10-01 15:05:33');
INSERT INTO training_plan VALUES(9,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs identifi├®s.\",\n        \"m├®thode\": \"Atelier pratique avec ├®tudes de cas.\",\n        \"livrables\": \"Rapport d''analyse des cas trait├®s.\",\n        \"dur├®e_estim├®e\": \"2 semaines\",\n        \"s├®quencement\": \"S2\",\n        \"crit├¿res_de_validation\": \"├ëvaluation des cas par le formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs sp├®cifiques.\",\n        \"m├®thode\": \"Micro-learning sur les concepts cl├®s.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"dur├®e_estim├®e\": \"1 semaine\",\n        \"s├®quencement\": \"S4\",\n        \"crit├¿res_de_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire pratiques.\",\n        \"m├®thode\": \"Coaching individuel sur des t├óches sp├®cifiques.\",\n        \"livrables\": \"Feedback ├®crit sur les performances.\",\n        \"dur├®e_estim├®e\": \"3 semaines\",\n        \"s├®quencement\": \"S4 ├á S8\",\n        \"crit├¿res_de_validation\": \"Am├®lioration mesurable des performances.\"\n      }\n    ],\n    \"├®ch├®ancier\": {\n      \"S2\": \"Atelier pratique\",\n      \"S4\": \"Micro-learning et d├®but du coaching\",\n      \"S8\": \"├ëvaluation finale des comp├®tences\"\n    }\n  }\n}\n```"}}','2025-10-01 15:06:12');
INSERT INTO training_plan VALUES(10,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Renforcer l''autonomie dans l''activit├®\",\n        \"m├®thode\": \"Coaching individuel\",\n        \"livrables\": \"Rapport de progr├¿s\",\n        \"dur├®e_estim├®e\": \"2 semaines\",\n        \"s├®quencement\": \"S2\",\n        \"crit├¿res_de_validation\": \"Am├®lioration de l''autonomie mesur├®e par des indicateurs de performance\"\n      },\n      {\n        \"objectif\": \"Acqu├®rir des comp├®tences de base suppl├®mentaires\",\n        \"m├®thode\": \"Atelier pratique\",\n        \"livrables\": \"Certificat de participation\",\n        \"dur├®e_estim├®e\": \"2 semaines\",\n        \"s├®quencement\": \"S4\",\n        \"crit├¿res_de_validation\": \"├ëvaluation des comp├®tences acquises par un test\"\n      },\n      {\n        \"objectif\": \"D├®velopper des savoir-faire sp├®cifiques\",\n        \"m├®thode\": \"Micro-learning\",\n        \"livrables\": \"Module de formation en ligne\",\n        \"dur├®e_estim├®e\": \"1 semaine\",\n        \"s├®quencement\": \"S8\",\n        \"crit├¿res_de_validation\": \"Taux de compl├®tion du module et ├®valuation finale\"\n      }\n    ],\n    \"├®ch├®ancier\": {\n      \"S2\": \"Coaching individuel\",\n      \"S4\": \"Atelier pratique\",\n      \"S8\": \"Micro-learning\"\n    }\n  }\n}\n```"}}','2025-10-01 15:11:52');
INSERT INTO training_plan VALUES(11,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans l''utilisation des outils sp├®cifiques.\",\n        \"m├®thode\": \"Atelier pratique avec mise en situation.\",\n        \"livrables\": \"Rapport d''auto-├®valuation et feedback des pairs.\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Satisfaction des participants et am├®lioration des performances mesur├®es.\",\n        \"jalon\": \"S2\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases th├®oriques n├®cessaires ├á l''activit├®.\",\n        \"m├®thode\": \"Micro-learning via modules en ligne.\",\n        \"livrables\": \"Certificat de compl├®tion des modules.\",\n        \"dur├®e_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Ach├¿vement des modules avec un score minimum de 80%.\",\n        \"jalon\": \"S2\"\n      },\n      {\n        \"objectif\": \"D├®velopper des comp├®tences avanc├®es dans les savoir-faire identifi├®s.\",\n        \"m├®thode\": \"Coaching individuel avec un expert.\",\n        \"livrables\": \"Plan de d├®veloppement personnel et rapport de progr├¿s.\",\n        \"dur├®e_estimee\": \"4 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Am├®lioration des performances dans les t├óches sp├®cifiques.\",\n        \"jalon\": \"S4\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et modules de micro-learning\",\n      \"S4\": \"Coaching et suivi des progr├¿s\",\n      \"S8\": \"├ëvaluation finale des comp├®tences acquises\"\n    }\n  }\n}\n```"}}','2025-10-01 15:18:47');
INSERT INTO training_plan VALUES(12,111,13,1,'PLAN_DE_FORMATION','{"type": "PLAN_DE_FORMATION", "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "performances_cibles": ["Qualit├®", "D├®lais"], "hypotheses": []}, "axes": [{"intitule": "Mise ├á niveau Savoirs", "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"option": "Judicieuse", "methodes": ["micro-learning", "atelier pratique"], "contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "prerequis": [], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "criteres_de_validation": ["0 erreur sur cas test"]}], "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}]}], "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "meta": {"source": "fallback_parse_error", "raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs identifi├®s.\",\n        \"m├®thode\": \"Atelier pratique sur les savoirs sp├®cifiques.\",\n        \"livrables\": \"Rapport d''├®valuation des comp├®tences acquises.\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation des comp├®tences par un formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"m├®thode\": \"Micro-learning sur les fondamentaux.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"dur├®e_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire pratiques.\",\n        \"m├®thode\": \"Coaching individuel sur les savoir-faire.\",\n        \"livrables\": \"Plan d''action personnalis├®.\",\n        \"dur├®e_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback positif du coach.\"\n      },\n      {\n        \"objectif\": \"Am├®liorer les HSC.\",\n        \"m├®thode\": \"Compagnonnage avec un expert.\",\n        \"livrables\": \"Rapport de suivi de progression.\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"├ëvaluation par l''expert.\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning.\",\n      \"S4\": \"Coaching et compagnonnage.\",\n      \"S8\": \"├ëvaluation finale des comp├®tences.\"\n    }\n  }\n}\n```"}}','2025-10-01 15:22:13');
CREATE TABLE user_activity_plans (

  id           INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  user_id      INTEGER NOT NULL,

  activity_id  INTEGER NOT NULL,

  role_id      INTEGER,

  content      TEXT    NOT NULL,        -- JSON du plan

  created_at   TEXT    NOT NULL,        -- ISO 8601

  updated_at   TEXT    NOT NULL,        -- ISO 8601

  UNIQUE(user_id, activity_id)

);
INSERT INTO user_activity_plans VALUES(1,111,1,13,'{"axes": [{"intitule": "Mise ├á niveau Savoirs", "jalons": [{"semaine": 2, "verif": "mini-├®valuation"}, {"semaine": 4, "verif": "KPI interm├®diaires"}, {"semaine": 8, "verif": "KPI finaux"}], "justification": "├ëcarts d├®tect├®s sur certains savoirs / commentaires manager", "objectifs_pedagogiques": ["Assimiler les concepts cl├®s"], "parcours": [{"contenus_recommandes": ["Module interne A", "Cas dÔÇÖexercice"], "criteres_de_validation": ["0 erreur sur cas test"], "duree_estimee_heures": 6, "livrables_attendus": ["Checklist appliqu├®e"], "methodes": ["micro-learning", "atelier pratique"], "option": "Judicieuse", "prerequis": []}]}], "contexte_synthetique": {"activite": "Activit├® (d├®mo)", "hypotheses": [], "performances_cibles": ["Qualit├®", "D├®lais"]}, "meta": {"raw": "```json\n{\n  \"plan_de_formation\": {\n    \"actions\": [\n      {\n        \"objectif\": \"Am├®liorer l''autonomie dans les savoirs identifi├®s.\",\n        \"m├®thode\": \"Atelier pratique sur les savoirs sp├®cifiques.\",\n        \"livrables\": \"Rapport d''├®valuation des comp├®tences acquises.\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"├ëvaluation des comp├®tences par un formateur.\"\n      },\n      {\n        \"objectif\": \"Renforcer les bases des savoirs.\",\n        \"m├®thode\": \"Micro-learning sur les fondamentaux.\",\n        \"livrables\": \"Quiz de validation des connaissances.\",\n        \"dur├®e_estimee\": \"1 semaine\",\n        \"sequencement\": \"S2\",\n        \"criteres_validation\": \"Score minimum de 80% au quiz.\"\n      },\n      {\n        \"objectif\": \"D├®velopper les savoir-faire pratiques.\",\n        \"m├®thode\": \"Coaching individuel sur les savoir-faire.\",\n        \"livrables\": \"Plan d''action personnalis├®.\",\n        \"dur├®e_estimee\": \"3 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"Feedback positif du coach.\"\n      },\n      {\n        \"objectif\": \"Am├®liorer les HSC.\",\n        \"m├®thode\": \"Compagnonnage avec un expert.\",\n        \"livrables\": \"Rapport de suivi de progression.\",\n        \"dur├®e_estimee\": \"2 semaines\",\n        \"sequencement\": \"S4\",\n        \"criteres_validation\": \"├ëvaluation par l''expert.\"\n      }\n    ],\n    \"echancier\": {\n      \"S2\": \"Ateliers et micro-learning.\",\n      \"S4\": \"Coaching et compagnonnage.\",\n      \"S8\": \"├ëvaluation finale des comp├®tences.\"\n    }\n  }\n}\n```", "source": "fallback_parse_error"}, "synthese_charge": {"duree_totale_estimee_heures": 6, "impact_organisation": "mod├®r├®", "recommandation_globale": "Lancer un micro-parcours de 2 semaines."}, "type": "PLAN_DE_FORMATION"}','2025-10-01T15:11:59','2025-10-01T15:22:21');
CREATE TABLE time_project (

  id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  name TEXT,

  created_at TEXT DEFAULT (now())

);
INSERT INTO time_project VALUES(2,'test','2025-10-03 09:30:52.850116');
INSERT INTO time_project VALUES(3,'Premier Projet ABs','2025-10-03 10:02:08.377672');
CREATE TABLE time_project_line (

  id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  project_id INTEGER NOT NULL REFERENCES time_project(id) ON DELETE CASCADE,

  activity_id INTEGER NOT NULL REFERENCES activities(id),

  duration_minutes REAL DEFAULT 0,

  delay_minutes REAL DEFAULT 0,

  nb_people INTEGER NOT NULL DEFAULT 1

);
INSERT INTO time_project_line VALUES(2,2,1,20.0,720.0,4);
INSERT INTO time_project_line VALUES(3,3,1,145.0,5040.0,2);
INSERT INTO time_project_line VALUES(4,3,16,20.0,3.5,3);
CREATE TABLE time_role_analysis (

  id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  role_id INTEGER NOT NULL REFERENCES roles(id),

  js INTEGER,

  sa INTEGER,

  created_at TEXT DEFAULT (now())

, name TEXT DEFAULT 'Analyse r├┤le');
INSERT INTO time_role_analysis VALUES(2,13,NULL,NULL,'2025-10-09 07:06:14.701715','Analyse r├┤le');
INSERT INTO time_role_analysis VALUES(3,13,NULL,NULL,'2025-10-09 11:23:06.228715','Analyse r├┤le vDEf');
INSERT INTO time_role_analysis VALUES(4,13,NULL,NULL,'2025-10-09 11:25:04.225551','A WebDev v1');
CREATE TABLE time_weakness (

  id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  activity_id INTEGER NOT NULL REFERENCES activities(id),

  task_id INTEGER REFERENCES tasks(id),

  duration_std_minutes  REAL DEFAULT 0,

  delay_std_minutes REAL DEFAULT 0,

  recurrence TEXT NOT NULL,

  frequency INTEGER NOT NULL DEFAULT 1,

  weakness TEXT,

  work_added_qty REAL DEFAULT 0,

  work_added_unit TEXT NOT NULL DEFAULT 'minutes',

  wait_added_qty REAL DEFAULT 0,

  wait_added_unit TEXT NOT NULL DEFAULT 'minutes',

  prob_denom INTEGER NOT NULL DEFAULT 1,

  created_at TEXT DEFAULT (now())

);
INSERT INTO time_weakness VALUES(1,1,NULL,75.0,1440.0,'journalier',1,'internet ├á crash',20.0,'minutes',55.0,'minutes',1,'2025-10-09 12:38:00.120437');
CREATE TABLE company_params (

  id INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  Js INTEGER DEFAULT 5,   -- jours/semaine

  Sa INTEGER DEFAULT 47,  -- semaines/an travaill├®es

  Ja INTEGER DEFAULT 220  -- jours/an travaill├®s

);
CREATE TABLE time_role_line (

  id                INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,

  role_analysis_id  INTEGER NOT NULL REFERENCES time_role_analysis(id) ON DELETE CASCADE,

  activity_id       INTEGER NOT NULL REFERENCES activities(id),

  recurrence        TEXT NOT NULL,     -- 'journalier' | 'hebdomadaire' | 'mensuel' | 'annuel'

  frequency         INTEGER NOT NULL DEFAULT 1

, duration_minutes REAL, delay_minutes    REAL DEFAULT 0, nb_people        INTEGER NOT NULL DEFAULT 1);
INSERT INTO time_role_line VALUES(4,2,11,'journalier',1,NULL,0.0,1);
INSERT INTO time_role_line VALUES(5,2,1,'journalier',1,NULL,0.0,1);
INSERT INTO time_role_line VALUES(6,2,4,'mensuel',3,NULL,0.0,1);
INSERT INTO time_role_line VALUES(7,3,11,'journalier',1,260.0,0.0,1);
INSERT INTO time_role_line VALUES(8,3,1,'journalier',1,75.0,0.0,1);
INSERT INTO time_role_line VALUES(9,3,4,'hebdomadaire',3,40.0,0.0,1);
INSERT INTO time_role_line VALUES(10,4,11,'annuel',10,260.0,0.0,1);
INSERT INTO time_role_line VALUES(11,4,1,'mensuel',3,75.0,0.0,1);
INSERT INTO time_role_line VALUES(12,4,4,'hebdomadaire',6,40.0,0.0,1);
INSERT INTO time_role_line VALUES(13,4,2,'journalier',2,20.0,0.0,1);
CREATE UNIQUE INDEX ix_activities_shape_id ON activities (shape_id);
CREATE UNIQUE INDEX ix_data_shape_id ON data (shape_id);
CREATE INDEX idx_perf_pers_user_activity

ON performance_personnalisee(user_id, activity_id);
CREATE INDEX idx_prerequis_user_act ON prerequis_comment(user_id, activity_id);
CREATE INDEX idx_prerequis_item ON prerequis_comment(item_type, item_id);
CREATE INDEX idx_training_plan_user_role_act ON training_plan(user_id, role_id, activity_id);
CREATE INDEX idx_pph_perf_changed ON performance_personnalisee_historique (performance_id, changed_at);
CREATE INDEX idx_pph_user_act ON performance_personnalisee_historique (user_id, activity_id, changed_at);
CREATE INDEX idx_uap_user ON user_activity_plans(user_id);
CREATE INDEX idx_uap_activity ON user_activity_plans(activity_id);
CREATE INDEX idx_tprj_line_project ON time_project_line(project_id);
CREATE INDEX idx_tweak_act ON time_weakness(activity_id);
CREATE INDEX idx_tweak_task ON time_weakness(task_id);
CREATE INDEX idx_trline_role_analysis ON time_role_line(role_analysis_id);
CREATE INDEX idx_trline_activity ON time_role_line(activity_id);
CREATE INDEX idx_activities_duration ON activities(duration_minutes);
CREATE INDEX idx_activities_delay    ON activities(delay_minutes);
CREATE INDEX idx_tasks_activity      ON tasks(activity_id);
COMMIT;
-- ==== fin script ====

